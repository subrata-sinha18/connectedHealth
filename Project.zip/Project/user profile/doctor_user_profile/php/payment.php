<?php
session_start();
$email = $_SESSION['email'];
//$fullname = $_SESSION['buyer_name'];

require("../../../instamojo/instamojo.php");
$amount = $_GET['amount'];
$date = $_GET['date'];
$id = $_GET['doctor_id'];
$patient_name = $_GET['patient_name'];
$age = $_GET['age'];
$gender = $_GET['gender'];
$phone = $_GET['phone'];
$total_seat = $_GET['total_seat'];

$api = new Instamojo\Instamojo('test_c6bf5a5294a498c235190b7bcef', 'test_b5da40d5be030e055cd9f366424', 'https://test.instamojo.com/api/1.1/');
try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => "DOCTOR PATIENT ONLINE PAYMENT SYSTEM",
        "amount" => $amount,
		"buyer_name" => $patient_name,
        "send_email" => true,
        "email" =>$email,
        "phone" =>$phone,
        "redirect_url" => "http://localhost/project/php/book_appointment.php?date=".$date."&doctor_id=".$id."&patient_name=".$patient_name."&age=".$age."&gender=".$gender."&phone=".$phone."&total_seat=".$total_seat
        ));
	$payment_url = $response['longurl'];
	$_SESSION["payment"] = "pending";
	header("Location:$payment_url");
    //print_r($response);
}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}
?>

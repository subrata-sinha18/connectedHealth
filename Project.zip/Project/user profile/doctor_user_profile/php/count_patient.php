<?php
require("../../../php/database.php");
$table_name = $_POST['table_name'];
$count_query = "SELECT COUNT(id) AS total FROM $table_name";
if($response = $db->query($count_query))
{
	if($data = $response->fetch_assoc());
	echo $data['total'];
}


else
{
	echo 0;
}




?>
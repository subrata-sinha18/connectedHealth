<?php
require("../../../php/database.php");
$date = $_POST['date'];
$doctor_id = $_POST['doctor_id'];
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM users WHERE email = '$email'";
$response = $db->query($get_id);
$id_data = $response->fetch_assoc();
$user_id = $id_data['id'];

$table_name = "doctor_".$doctor_id."_".$date;
$check = "SELECT user FROM $table_name WHERE user = $user_id";
if($response = $db->query($check))
{
    if($response->num_rows == 0)
    {
        echo "OK";
    }
    else
    {
        echo "You have already booked";
    }
}
else
{
    echo "OK";
}
?>
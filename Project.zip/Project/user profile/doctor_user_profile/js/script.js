// JavaScript Document


$(document).ready(function(){
var date = new Date(),
d = date.getDate(),
m = date.getMonth(),
y = date.getFullYear();
var i;
for(i=0;i<3;i++)
	{
		var curdate = new Date(y, m, d+i)
		var get_date = curdate.getDate();
		var get_month = curdate.getMonth()+1;
		var get_year = curdate.getFullYear();
		var n = curdate.getDay();
		var weekday = new Array(7);
		weekday[0] = "Sunday";
		weekday[1] = "Monday";
		weekday[2] = "Tuesday";
		weekday[3] = "Wednesday";
		weekday[4] = "Thursday";
		weekday[5] = "Friday";
		weekday[6] = "Saturday";
		var complete_date = get_date+"/"+get_month+"/"+get_year;
		var doctor_id = $(".doctor_id").html();
		var table_name = "doctor_"+doctor_id+"_"+get_date+"_"+get_month+"_"+get_year;
		
		var doctor_id = $(".doctor_id").html();
		var day = weekday[curdate.getDay()];
		var parent_div = document.createElement("DIV");
		parent_div.className = "booking text-center p-3 mx-5 my-3";
		var span_1 = document.createElement("SPAN");
		span_1.className = "bg-warning text-center date_span";
		span_1.innerHTML = complete_date;
		var span_2 = document.createElement("SPAN");
		span_2.className = "d-block pb-2 pt-3";
		span_2.innerHTML = weekday[n];
		var para = document.createElement("P");
		para.className = "p-0 m-0";
		var span_3 = document.createElement("SPAN")
//		span_3.innerHTML = "18 / 50";
		var span_4 = document.createElement("SPAN");
		span_4.className = "booked_"+i;
		
		
		var span_5 = document.createElement("SAPN");
		var total_seat = $(".total_seat").html();
		span_5.innerHTML = total_seat;
		span_3.append(span_4);
		demo(table_name,"booked_"+i);
		span_3.innerHTML += " / ";
		span_3.append(span_5);
		para.innerHTML = "Available : ";
		para.append(span_3);
		var div_1 = document.createElement("DIV");
		div_1.className = "progress mb-3 w-75";
		div_1.style.height = "7px";
		div_1.style.margin = "0 auto";
		var div_2 = document.createElement("DIV");
//		div_2.className = "progress-bar progress-bar-striped progress-bar-animated";
		div_2.style.hright = "7px";
		
//		var val_two = span_5.innerHTML;
//		var val_one = val_two-span_4.innerHTML;
//		console.log(val_one);
//		div_2.style.width = "75%";
		div_1.append(div_2);
		var btn = document.createElement("BUTTON");
		btn.className = "btn btn-danger";
		btn.setAttribute("disabled","disabled");
		var doctor_id = $(".doctor_id").html();
		btn.setAttribute("data-id",doctor_id);
		btn.setAttribute("data-toggle","modal");
		btn.setAttribute("data-target","#book_form");
		btn.innerHTML = "";
		
		parent_div.append(span_1);
		parent_div.append(span_2);
		parent_div.append(para);
		parent_div.append(div_1);
		parent_div.append(btn);
		$(".booking_box").append(parent_div);
		
		var input_days = $("#days").html();
		var all_days = input_days.split(",");
		var j;
	
		
		
		for(j=0;j<all_days.length-1;j++)
			{
				if(btn.innerHTML == "" || btn.innerHTML == "NOT AVAILABLE")
					{
						if(weekday[n].indexOf(all_days[j]) == -1)
							{
								btn.innerHTML = "NOT AVAILABLE";
							}
						else
							{
								btn.innerHTML = "BOOK NOW";
								btn.className = "btn btn-primary book_btn";
								btn.removeAttribute("disabled");
							}
					}
			}
		
		
	}
	
});


function demo(a,b){
	$.ajax({
			type : "POST",
			url : "php/count_patient.php",
			data : {
				table_name : a
			},
			success : function(response){
				var span = $("."+b).parent().children();
				var span_2 = span[1].innerHTML;
				var available = span_2-response;
				$("."+b).html(available);
				
				if(available == 0)
					{
						var btn_col = $("."+b).parent().parent().parent().children();
						btn_col[4].setAttribute("disabled","disabled");
						btn_col[4].className = "btn btn-warning";
						btn_col[4].innerHTML = "SEAT FULL";
						
					}
				var filled = span_2-available;
				var percentage = (filled/span_2)*100;
				var parent = $("."+b).parent().parent().parent().children().children();
				parent[1].style.width = percentage+"%";
				if(percentage > 90)
					{
						parent[1].className = "progress-bar bg-danger progress-bar-striped progress-bar-animated";
					}
				else if(percentage >70 && percentage <900)
					{
						parent[1].className = "progress-bar bg-warning progress-bar-striped progress-bar-animated";
					}
				else
					{
						parent[1].className = "progress-bar bg-primary progress-bar-striped progress-bar-animated";
					}
			}
		});
}


$(document).ready(function(){
	$(".backToHomeBtn").click(function(){
		window.location = "../user.php";
	});
});


















// JavaScript Document
//$(document).ready(function(){
//	$(".book_btn").each(function(){
//		$(this).click(function(e){
//			e.preventDefault();
//			var div = $(this).parent().children();			
//			var date = div[0].innerHTML;
//			var date_convert = date.replace("/","_");
//			var final_date = date_convert.replace("/","_");
//			alert(final_date);
//			var doctor_email = $(".doctor_email").html();
//			console.log(date);
//			$.ajax({
//				type : "POST",
//				url : "php/book_appointment.php",
//				data : {
//					date : btoa(final_date),
//					doctor_email : btoa(doctor_email)
//				},
//				beforeSend : function(){
//					
//				},
//				success : function(response){
//					alert(response);
//				}
//				
//			});
//		});
//	});
//});


$(document).ready(function(){
	$(".book_btn").each(function(){
		$(this).click(function(){
			var div = $(this).parent().children();			
			var date = div[0].innerHTML;
			var doctor_name = document.querySelector(".doctor_name").textContent;
			var cont = `<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title text-primary" id="exampleModalLabel">`+doctor_name+`</h4>
					<h5 class="date_cur">`+date+`</h4>
					<i class="fa fa-close" data-dismiss="modal"></i>
				</div>
				
				<div class="modal-body p-4 px-5">
					<h5 class="text-center text-warning">ONLINE BOOKING</h5>
					<div class="input-group mb-4">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon2">Paitent's Name</span>
						</div>
						<input type="text" class="form-control" placeholder="e.g.- John Snow" id="patient-name">
					</div>
					<div class="input-group mb-4">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon2">Age</span>
						</div>
						<input type="text" class="form-control" placeholder="25" id="age">
					</div>
					<div class="input-group mb-4">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon2">Gender</span>
						</div>
						<select class="form-control" id="gender">
							<option>Male</option>
							<option>Female</option>
						</select>
					</div>
					<div class="input-group mb-4">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon2">Phone Number</span>
						</div>
						<input type="text" class="form-control" placeholder="+91 94000 12345" id="phone">
					</div>
				</div>
				
				<div class="modal-footer">
					<button class="btn btn-primary booking_btn">Book Now</button>
				
				</div>
			</div>`;
			$(".modal-dialog").html(cont);
			$(".booking_btn").click(function(e){
				e.preventDefault();
				var date = $(".date_cur").html();
				var date_convert = date.replace("/","_");
				var final_date = date_convert.replace("/","_");
				var doctor_id = $(".doctor_id").html();
				var patient_name = $("#patient-name").val();
				var age = $("#age").val();
				var gender = $("#gender").val();
				var phone = $("#phone").val();
				var total_seat = $(".total_seat").html();
				var table_name = "doctor_"+doctor_id+"_"+final_date;
				
				var doctor_charge = $(".doctor_charge").html();
				var total_amount = Number(doctor_charge)+50;
				$.ajax({
					type : "POST",
					url : "php/checkedForBooking.php",
					data : {
						date : final_date,
						doctor_id : doctor_id

					},
					success : response =>{
						if(response.trim() == "OK")
						{
							window.location.href = "php/payment.php?amount="+total_amount+"&date="+final_date+"&doctor_id="+doctor_id+"&patient_name="+patient_name+"&age="+age+"&gender="+gender+"&phone="+phone+"&total_seat="+total_seat;
						}
						else
						{
							alert("You have already registered");
						}
					}
				});
				// window.location.href = "php/payment.php?amount="+total_amount+"&date="+final_date+"&doctor_id="+doctor_id+"&patient_name="+patient_name+"&age="+age+"&gender="+gender+"&phone="+phone+"&total_seat="+total_seat;
//				$.ajax({
//					type : "POST",
//					url : "php/book_appointment.php",
//					data : {
//						date : btoa(final_date),
//						doctor_id : btoa(doctor_id),
//						patient_name : btoa(patient_name),
//						age : btoa(age),
//						gender : btoa(gender),
//						phone : btoa(phone),
//						total_seat : btoa(total_seat)
//						
//					},
//					beforeSend : function(){
//						$(".booking_btn").attr("disabled","disabled");
//						$(".booking_btn").html("Please wait ...");
//					},
//					
//					success : function(response){
//						alert(response);
//						if(response.trim() == "	Data not inserted" || response.trim() == "f" || response.trim() == "NOT BOOKED" || response.trim() == "seat FULL" || response.trim() == "NOT CREATE" )
//							{
//								$(".modal-body").html("");
//								var mess = `<h1 class="text-danger text-center my-5 animated rubberBand">`+response+`</h1>`;
//								$(".modal-body").html(mess);
//								$(".modal-footer").addClass("d-none");
//							}
//						else
//							{
//								var json_response = JSON.parse(response);
//								console.log(json_response);
//								var doctor_tabel_id = json_response[0];
//								var patient_phone = json_response[1];
//								var user_table = json_response[2];
//								var book_date = json_response[3];
//								var doctor_number = json_response[4];
////								$(".modal-body").html("");
////								var mess = `<h1 class="text-danger text-center my-5 animated rubberBand">BOOKED SUCCESSFULLY</h1>`;
////								$(".modal-body").html(mess);
////								$(".modal-footer").addClass("d-none");
////								
////								setTimeout(function(){
//////									window.location = "../user.php";
////									window.location = location.href;
////								},3000);
//							}
//					}
//				});
			});
		})
		
		
	});
});
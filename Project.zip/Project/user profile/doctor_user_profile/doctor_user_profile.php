<?php
session_start();
if(empty($_SESSION['email']))
{
	echo "not found";
	header("Location:../index.html");
	exit;
}
$doctor_email = $_GET['doctor_email'];
require("../../php/database.php");
$get = "SELECT image_path,name,locality,specialization,clinic_address,charge_per_patient,visit_on,experience,id,total_seat FROM doctors WHERE email = '$doctor_email'";
$response = $db->query($get);
$data = $response->fetch_assoc();
$image_path = $data['image_path'];
$actual_image_path = str_replace("../","",$image_path);
$name = $data['name'];
$locality = $data['locality'];
$special = $data['specialization'];
$address = $data['clinic_address'];
$amount = $data['charge_per_patient'];
$visit_on = $data['visit_on'];
$experience = $data['experience'];
$id = $data['id'];
$total_seat = $data['total_seat'];
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title><?php echo $name ?></title>
<link rel="icon" href="<?php echo '../../doctor profile/'.$actual_image_path ?>" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/animate.css">
	<!-- <link rel="stylesheet" href="css/jquery-ui.css"> -->
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<!-- <script src="js/jquery-ui.js"></script> -->
	<script src="js/book_appointment.js"></script>
	<script src="js/booking.js"></script>
	<style>
		<?php require_once("../../assest/css/header.php"); ?>
		<?php require_once("../../assest/css/footer.php"); ?>
	</style>
	
</head>
<body>
	<div>
		<?php require_once("../../assest/html/header_doctorUser.php"); ?>
		<div class="container my-5">
			<div class="jumbotron d-flex p-3" style="border-bottom:1px solid #ccc">
				<div class="image-box position-relative" style="width:150px;height:150px;border-radius:50%;overflow: hidden">
					<img src="<?php echo '../../doctor profile/'.$actual_image_path ?>" style="width:100%;height:100%" />
				</div>
				<div class="w-25 ml-auto d-flex flex-column justify-content-end">
					<h2 class="doctor_name d-flex" style="font-family: sans-serif"><i class="fa fa-check d-flex justify-content-center align-items-center flex-column mt-2 mr-2" style="width:25px; height:25px;border-radius:50%;background-color:green;color:#fff;font-size:16px;"></i><?php echo $name ?></h2>
					<!-- <span class="d-flex mb-2"></i>&nbsp; Medical Registration Verified</span> -->
					<!-- <span><?php //echo $locality ?></span> -->
					<span class="mb-2"><?php echo $special ?></span>
					<span class="mb-2"><span><?php echo $experience.", "; ?></span>Years Experience Overall</span>
					<span class="doctor_email mb-2"><?php echo $doctor_email; ?></span>
					<span class="doctor_id d-none"><?php echo $id; ?></span>
					<span class="total_seat d-none"><?php echo $total_seat; ?></span>
				</div>
				
			</div>
			
			<div class="container details p-3">
				<div class="address p-3 d-flex">
					<div class="w-75">
						<h5>
							<i class="fa fa-home text-primary" style="font-size: 25px;"></i>
							<span><?php echo $locality; ?></span>
						</h5>
						<h5>
							<i class="fa fa-street-view text-warning" style="font-size: 25px;"></i>
							<span><?php echo $address; ?></span>
						</h5>
						
					</div>
					<div class="w-25">
						<p>
							<i class="fa fa-rupee text-primary" style="font-size:20px;"></i>
							<span>Doctor's Fee : <span class="doctor_charge"><?php echo $amount; ?></span></span>
						</p>
						<p>
							<i class="fa fa-rupee text-primary" style="font-size:20px;"></i>
							<span> Booking Charge : 50.00</span>
						</p>
					
					</div>
				
				</div>
				<div class="">
					<span>Doctor Visit &nbsp;<span style="font-weight:bold" id="days"><?php echo $visit_on; ?></span></span><br />
					
				</div>
				<div class="booking_box p-3 d-flex flex-wrap justify-content-between">

					
					
					
					
				</div>
				
			
			</div>
		</div>
		<?php require_once("../../assest/html/footer.php"); ?>
	</div>

	
	
<!--	------------Modal-->
	<div class="modal" id="book_form">
		<div class="modal-dialog modal-lg">
			
		</div>
	</div>
	
	
</body>
</html>











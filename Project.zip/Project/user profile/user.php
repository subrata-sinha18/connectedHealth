<?php
session_start();
if(empty($_SESSION['email']))
{
	echo "not found";
	header("Location:../index.html");
	exit;
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title>
	<?php
		require("../php/database.php");
		$email = $_SESSION['email'];
		$get_name = "SELECT name,contact_number,locality FROM users WHERE email = '$email'";
		$name_response = $db->query($get_name);
		$data = $name_response->fetch_assoc();
		$final_name = $data['name'];
		$locality = $data['locality'];
		$contact_number = $data['contact_number'];
		echo $final_name;
	?></title>
<link rel="icon" href="images/logo.png" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link href="https://fonts.googleapis.com/css?family=Righteous&display=swap|PT+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="DataTables/datatables.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/search_doctor_ajax.js"></script>
	<script src="js/auto_select_region_ajax.js"></script>
	<script src="js/doctor_search_by_name.js"></script>
	<script src="js/select_doctor_by_clinic.js"></script>
	<script src="js/change_password.js"></script>
	<script src="DataTables/datatables.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<style>
		<?php require_once("../assest/css/header.php"); ?>
		<?php require_once("../assest/css/footer.php"); ?>
	</style>
</head>
<body>
    <div>
	<?php require_once("../assest/html/header.php"); ?>
		<div class="main-con d-flex">
			<div class="nav-box py-4 px-3">
				<div>
					<h5 class="text-white mb-3">User's Area</h5>
					<ul id="myTab" role="tablist">
						<li class="profile_link"><a href="#"><i class="fa fa-fw fa-user-md" style="font-size:24px"></i>My Profile</a></li>
						<li class="appointment_link"><a href="#"><i class="fa fa-fw fa-user" style="font-size:24px"></i>Appointment History</a></li>
						<li class="wallet_link"><a href="#"><i class="fa fa-fw fa-inr" style="font-size:24px"></i>My Wallet</a></li>
						<li class="book_link"><a href="#"><i class="fa fa-fw fa-book" style="font-size:24px"></i>Book Appointment</a></li>
						<li class="request_link"><a href="#"><i class="fa fa-fw fa-file" style="font-size:24px"></i>Request Diagnosis</a></li>
						<li class="password_link"><a href="#"><i class="fa fa-fw fa-user" style="font-size:24px"></i>Change Password</a></li>
						<li class="signout_link"><a href="php/logout.php"><i class="fa fa-fw fa-lock" style="font-size:24px"></i>Sign Out</a></li>
					</ul>
				</div>
			</div>
			<div class="main-section-box">
				<div class="header-name-box p-3 d-flex">
					<div class="w-50">
						<span class="text-white mb-1">WELCOME</span>
						<h3 class="text-white">
							<?php
							echo $final_name;
							?>
						</h3>
					</div>
					<div class="w-50 d-flex justify-content-end align-items-end">
						<p class="p-0 m-0 text-white">Login As : &nbsp;&nbsp;<span>Patient</span></p>
					</div>
					
					
				</div>
				<div class="main-section">
					<div class="profile">
						<div class="profile_con p-4 userContainer user-pro">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>User's Details</h4>
								</div>
								<div class="card-body">
									<ul class="list-group details-ul">
										<li class="list-group-item py-4"><span>Name : </span><span><?php echo $final_name; ?></span></li>
										<li class="list-group-item py-4"><span>Email Id : </span><span><?php echo $email; ?></span></li>
										<li class="list-group-item py-4"><span>Contact Number : </span><span><?php echo $contact_number; ?></span></li>
										<li class="list-group-item py-4"><span>Locality : </span><span><?php echo $locality; ?></span></li>							
									</ul>
								</div>

							</div>
							

						</div>
						<div class="appointment_con p-4 userContainer user-pro" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>Appointment Details</h4>
								</div>
								<div class="card-body table-responsive-sm">
									<table class="table table-dark table-hover" id="myTable">
										<thead>
										  <tr>
											  <th scope="col">Sl No.</th>
											  <th scope="col">Token No.</th>
											  <th scope="col">Patient Name</th>
											  <th scope="col">Patient Phone</th>
											  <th scope="col">Date</th>
											  <th scope="col">Coctor Name</th>
											  <th scope="col">Booked Date</th>
											  <th scope="col">Doctor Phone</th>
											  <th scope="col">Clinic Name</th>
											  <th scope="col">Clinic Address</th>
											  <th scope="col">Doctor Charge</th>
											  
											  
											
										  </tr>
										</thead>
										<tbody class="tbody">
											
										</tbody>
									</table>
								</div>
							</div>
							

						</div>
						<div class="wallet_con p-4 userContainer user-pro" style="display: none">
							

							<div class="card">
								<div class="card-header bg text-white">
									<h4>Wallet</h4>
								</div>
								<div class="card-body table-responsive-sm">
									<h1>Wallet</h1>
								</div>
							</div>
							

						</div>
						<div class="booking_con p-4 userContainer user-pro" style="display: none">
							
							<div class="card booking-card">
								<div class="card-header bg text-white">
									<h4>Bookings Appointment</h4>
								</div>	
								<div class="card-body bg-dark px-5">
									<form autocomplete="off">
										<div class="form-group">
											<label for="select_region" class="text-white">Select Region</label>
											<select class="form-control" id="select_region">
												<option>Select Region</option>
												
											</select>
										  </div>
										  <div class="form-group">
											<label for="specialization text-white" class="text-white">Select Specialization</label>
											<select name="login_as" id="specialization" class="form-control" disabled="disabled">
												<option class="dropdown-item">Select Specialization</option>

											</select>
										</div>
										  <p class="text-center p-0 m-0 text-white">OR</p>
										  <div class="form-group position-relative">
											<label for="doctor" class="text-white">Doctor's Name</label>
											  <input type="text" class="form-control" id="doctor">
											  <ul class="list-group doctor_list_box position-absolute w-100" style="z-index" >
												  
												  
											  </ul>


										</div>
										<p class="text-center p-0 m-0 text-white">OR</p>	
										<div class="form-group position-relative">
											<label for="clinic" class="text-white">Clinics</label>
											<input type="text" class="form-control" id="clinic">
											<ul class="list-group clinic_list_box position-absolute w-100" style="z-index:1">
											
											</ul>
										</div>
										<button class="btn btn-success search_btn" type="submit" disabled="disabled">Search</button>
									</form>
								</div>
							</div>

							<div class="doctors py-5 w-100 d-flex flex-wrap justify-content-between">
							
							</div>
							

						</div>
						<div class="diagnosis_con p-4 userContainer user-pro" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>Diagnosis Request</h4>
								</div>
								<div class="card-body table-responsive-sm">
									<div class="trackTableCon" style="display:block">
										<table class="table table-dark">
											<thead>
											<tr>
												<th scope="col">Sl No.</th>
												<th scope="col">Token No.</th>
												<th scope="col">Patient Name</th>
												<th scope="col">Date</th>
												<th scope="col">Doctor Name</th>
												<th scope="col">Booking Status</th>

											</tr>
											</thead>
											<tbody class="trackBody">
												
											</tbody>
										</table>
									</div>
									<div class="track_details py-5 row" style="background-color:black;display:none;">
										<div class="trackInner col-md-6 px-5">
										
										
										</div>
										<div class="trackInnerResult col-md-6 row text-light">
										    <div class="col-8">
											    <p>Date</p>
												<p>Total number of patients<p>
												<p>Patients checked<p>
												<p>Patients remaining</p>
												<!-- <p>Expected time of checking</p> -->
										    </div>
											<div class="col-4">
												<p class="checkDate"></p>
												<p class="TotalPatients"></p>
												<p class="TotalChecked">0</p>
												<p class="TotalRemainingPatients"></p>
												<!-- <p class="ExpectedTimeofChecking"></p> -->
											</div>
										
										
										</div>
									
									</div>
									
								</div>
							</div>
							

						</div>
						<div class="password_con p-4 userContainer user-pro" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>Change Password</h4>
								</div>	
								<div class="card-body bg-dark px-5">
									<form autocomplete="off">
										<div class="form-group">
											<label for="old_password" class="text-white">Enter Old Password</label>
											<input type="password" class="form-control" id="old_password" />
										</div>
										<div class="form-group">
											<label for="new_password" class="text-white">Enter New Password</label>
											<input type="password" class="form-control" id="new_password" />
										</div>
										<div class="form-group">
											<label for="repeat_password" class="text-white">Repeat New Password</label>
											<input type="password" class="form-control" disabled="disabled" id="repeat_password" />
										</div>
										<button class="btn btn-success change_btn" disabled="disabled" type="submit" >Change Password</button>
									</form>
									<div class="changed_notice p-2">
				
									</div>
								</div>
							</div>
							

						</div>
					</div>
				</div>

			</div>
		</div>
		<?php require_once("../assest/html/footer.php"); ?>
	</div>
   

	
	
</body>
</html>











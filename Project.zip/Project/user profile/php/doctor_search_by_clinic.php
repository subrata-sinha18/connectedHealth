<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$val = $_POST['val'];
$query_doctor = "SELECT clinic_name FROM doctors WHERE clinic_name LIKE '%$val%'";
if($response = $db->query($query_doctor))
{
	if($data = $response->fetch_assoc())
	{
		$name[] = $data['clinic_name'];
	}
	else
	{
		echo "not found";
		exit();
	}
	if(sizeof($name) >0)
	{
		echo json_encode($name);
	}
	
}
else
{
	echo "not found";
}


?>
<?php
require("../../php/database.php");
session_start();
$user_email = $_SESSION['email'];
$get_user = "SELECT id FROM users WHERE email = '$user_email'";
if($response = $db->query($get_user))
{
	$id_data = $response->fetch_assoc();
	$user_id = $id_data['id'];
	echo $user_id;
}
else
{
	echo "id not found";
}


?>
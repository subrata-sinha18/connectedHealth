<?php
echo "subrata";
// require("../../php/database.php");
// $doctor_email = base64_decode($_POST['doctor_email']);
// echo $doctor_email;


?>
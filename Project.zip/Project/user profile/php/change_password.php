<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$old_password = md5(base64_decode($_POST['old_password']));
$new_password = base64_decode($_POST['new_password']);
$password = md5(base64_decode($_POST['new_password']));
$repeat_password = base64_decode($_POST['repeat_password']);
$check_password = "SELECT email,password FROM users WHERE email = '$email' AND password = '$old_password'";
$response_password = $db->query($check_password);
if($response_password->num_rows != 0)
{
	if($new_password == $repeat_password)
	{
		$update_password = "UPDATE users SET password = '$password' WHERE email = '$email' AND password = '$old_password'";
		if($db->query($update_password))
		{
			echo "Successfully Changed Password";
		}
		else
		{
			echo "failed to update";
		}
		
	}
	else
	{
		echo "Password Not Matched";
	}
}
else
{
	echo "Enter Wornd Password";
}


?>
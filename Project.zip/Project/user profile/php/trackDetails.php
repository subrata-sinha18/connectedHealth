<?php
require("../../php/database.php");
$date = $_POST['date'];
$doctor_id = $_POST['id'];
$tableName = "doctor_".$doctor_id."_".$date;
$select = "SELECT check_status,checked_time,checked_at,user FROM $tableName";
if($response = $db->query($select))
{
    $details = [];
    while ($data = $response->fetch_assoc()) {
        array_push($details,$data);
    }
    echo json_encode($details);
}
else
{
    echo "error";
}

?>
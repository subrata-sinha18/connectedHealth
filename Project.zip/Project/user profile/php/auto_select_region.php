<?php
require("../../php/database.php");
$select_region = "SELECT locality FROM doctors";
$region_response = $db->query($select_region);
while($data = $region_response->fetch_assoc())
{
	$region[] = $data['locality'];
//	$arry_data = array_unique($region);
	
	
}
$uni = array_unique($region);
echo json_encode($uni);


?>
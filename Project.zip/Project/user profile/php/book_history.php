<?php
require("../../php/database.php");
session_start();
$user_email = $_SESSION['email'];
$get_user = "SELECT id FROM users WHERE email = '$user_email'";
if($response = $db->query($get_user))
{
	$id_data = $response->fetch_assoc();
	$user_id = $id_data['id'];
	$user_table = "user_".$user_id;
	$select_query = "SELECT * FROM $user_table";
	if($select_response = $db->query($select_query))
	{
		$user_data = [];
		while($select_data = $select_response->fetch_assoc())
		{
			array_push($user_data,$select_data);
		}
		echo json_encode($user_data);
	}
	else
	{
		echo "table not available";
	}
	// $select_all = "SELECT id FROM $user_table WHERE email = '$user_email'";
	// $response = $db->query($select_all);
	// while($data = $response->fetch_assoc())
	// {
	// 	$id[] = $data['id'];
	// }
	// $id_length = sizeof($id);
	// for($i=0;$i<$id_length;$i++)
	// {
	// 	$select_id = $id[$i];
	// 	$select = "SELECT id,patient_name,date,phone,book_date,doctor_name,doctor_number,clinic_name,clinic_address,doctor_charge FROM $user_table WHERE id='$select_id'";
	// 	$response = $db->query($select);
	// 	$data = $response->fetch_assoc();
	// 	$token_no = $data['id'];
	// 	$patient_name =  $data['patient_name'];
	// 	$date =  $data['date'];
	// 	$patient_phone =  $data['phone'];
	// 	$book_date =  $data['book_date'];
	// 	$doctor_name =  $data['doctor_name'];
	// 	$doctor_number =  $data['doctor_number'];
	// 	$clinic_name =  $data['clinic_name'];
	// 	$clinic_address =  $data['clinic_address'];
	// 	$doctor_charge =  $data['doctor_charge'];
	// 	$book_details[] = [$token_no,$patient_name,$date,$patient_phone,$book_date,$doctor_name,$doctor_number,$clinic_name,$clinic_address,$doctor_charge];
	// }
	// echo json_encode($book_details);
}
else
{
	echo "table not available";
}


?>

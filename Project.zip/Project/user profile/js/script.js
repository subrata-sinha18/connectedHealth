// JavaScript Document



//$(document).ready(function(){
//    $(".edit_profile").click(function(e){
//        e.preventDefault();
//        if($(this).html() == "Edit")
//        {
//            $(this).html("Save");
//            $(this).removeClass("btn-warning");
//            $(this).addClass("btn-primary");
//            $(".details-ul li span:nth-child(2)").attr("contenteditable","true");
//            $(".details-ul li span:nth-child(2)")[0].focus();
//            $(".details-ul li span:nth-child(2)").each(function(){
//                $(this).css("border","0.5px dashed rgb(0,0,255)");
//            })
//        }
//        else if($(this).html() == "Save")
//        {
//            $(".details-ul li span:nth-child(2)").attr("contenteditable","false");
//            $(".details-ul li span:nth-child(2)").each(function(){
//                $(this).css("border","none");
//            })
//            $(this).html("Edit");
//            alert("saved");
//            $(this).removeClass("btn-primary");
//            $(this).addClass("btn-warning");
//        }
//        
//    })
//});



$(document).ready(function(){
	$("#select_region").on("input",function(){
		if($(this).val() == "Select Region")
			{
				$("#specialization").attr("disabled","disabled");
			}
		else
			{
				$("#specialization").removeAttr("disabled");
			}
	})
});
$(document).ready(function(){
	$("#specialization").on("change",function(){
	if($(this).val() != "Select Specialization")
		{
			$(".search_btn").removeAttr("disabled");
		}
	else
		{
			$(".search_btn").attr("disabled","disabled");
		}
	})
});



$(document).ready(function(){
	$(".profile_link").click(function(){
		$(".appointment_con, .wallet_con, .booking_con, .diagnosis_con,.password_con").fadeOut(500,function(){
			$(".profile_con").fadeIn(500);
		});
	});
	
	$(".appointment_link").click(function(){
		$(".profile_con, .wallet_con, .booking_con, .diagnosis_con,.password_con").fadeOut(500,function(){
			$(".appointment_con").fadeIn(500);
		});
	});
	
	$(".wallet_link").click(function(){
		$(".profile_con, .appointment_con, .booking_con, .diagnosis_con,.password_con").fadeOut(500,function(){
			$(".wallet_con").fadeIn(500);
		});
	});
	$(".book_link").click(function(){
		$(".profile_con, .appointment_con, .wallet_con, .diagnosis_con,.password_con").fadeOut(500,function(){
			$(".booking_con").fadeIn(500,function(){
				$(".booking-card").fadeIn(500,function(){
					$(".doctors").html("");
					$(".booking-card form").trigger("reset");
					$(".doctor_list_box").show();
					$(".doctor_list_box").html("");
				});
			});
		});
	});
	
	$(".request_link").click(function(){
		$(".trackBody").html("");
		$(".trackInner").html("");
		tracting();
		$(".profile_con, .appointment_con, .wallet_con, .booking_con,.password_con,.track_details").fadeOut(500,function(){
			$(".diagnosis_con, .trackTableCon").fadeIn(500);
		});
	});
	$(".password_link").click(function(){
		$(".profile_con, .appointment_con, .wallet_con, .booking_con,.diagnosis_con").fadeOut(500,function(){
			$(".password_con").fadeIn(500);
		});
	});
	
});

$(document).ready(function(){
	$.ajax({
		type : "POST",
		url : "php/book_history.php",
		success : function(response){
			if(response.trim() != "table not available")
			{
				var json_response = JSON.parse(response);
				console.log(json_response);
				var i;
				for(i=0;i<json_response.length;i++)
					{
						let date = json_response[i].date.replace("_","/").replace("_","/");
						let booked_date = json_response[i].book_date.replace("-","/").replace("-","/");
						var tr = `<tr>
									<th class="bg-dark text-light text-center" scope="row">`+(i+1)+`</th>
									<td class="bg-dark text-light text-center">`+json_response[i].id+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].patient_name+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].phone+`</td>
									<td class="bg-dark text-light text-center">`+date+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].doctor_name+`</td>
									<td class="bg-dark text-light text-center">`+booked_date+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].doctor_number+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].clinic_name+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].clinic_address+`</td>
									<td class="bg-dark text-light text-center">`+json_response[i].doctor_charge+`</td>
								</tr>`;
						var tbody = document.getElementsByClassName("tbody");
						tbody[0].innerHTML += tr;
						
					}
	//			$(".appointment_con table tbody").html(tr);
					$('#myTable').DataTable();
					$('#myTable tbody').on('click', 'tr', function () {
						var data = table.row(this).data();
					} );

			}
		}
	});
});

let tracting = () =>{
	
$(document).ready(function(){
	$.ajax({
		type : "POST",
		url : "php/book_history.php",
		success : function(response){
			if(response.trim() != "table not available")
			{
				var json_response = JSON.parse(response);
				console.log(json_response);
				var i;
				for(i=0;i<json_response.length;i++)
					{
						let date = json_response[i].date.replace("_","/").replace("_","/");
						//let booked_date = json_response[i].book_date.replace("-","/").replace("-","/");
						var tr = `<tr>
									<th class="bg-dark text-light" scope="row">`+(i+1)+`</th>
									<td class="bg-dark text-light">`+json_response[i].id+`</td>
									<td class="bg-dark text-light">`+json_response[i].patient_name+`</td>
									<td class="bg-dark text-light date" data-id="${json_response[i].doctor_id}">`+date+`</td>
									<td class="bg-dark text-light">`+json_response[i].doctor_name+`</td>
									<td class="bg-dark text-light"><button class="btn btn-primary tractBtn">Check Status</button></td>
									
								</tr>`;
						var tbody = document.getElementsByClassName("trackBody");
						tbody[0].innerHTML += tr;
						
					}
					$(".tractBtn").each(function(){
						$(this).click(function(){
							$(".TotalChecked").html("0");
							let appointment_date = $(this).parent().parent().children(".date").html();
							let appointment_date_parts = appointment_date.split("/");
							let appointment_final_date = appointment_date_parts[0]+"_"+appointment_date_parts[1]+"_"+appointment_date_parts[2];
							let doctor_id = $(this).parent().parent().children(".date").attr("data-id");
							$.ajax({
								url : "php/getUserId.php",
								success : response =>{
									let user_id = response;
									$.ajax({
										type : "POST",
										url : "php/trackDetails.php",
										data : {
											date : appointment_final_date,
											id : doctor_id
										},
										beforeSend : () =>{
		
										},
										success : response =>{
											console.log(response);
											if(response.trim() != "error")
											{
												$(".trackTableCon").fadeOut(500, function(){
													$(".track_details").fadeIn(500, function(){
														let data = JSON.parse(response);
														console.log(data.length);
														$(".checkDate").html(appointment_date);
														$(".TotalPatients").html(data.length);
														for(let i = 0;i<data.length;i++)
														{

															
															let borderColorofUser = "";
															if(user_id == data[i].user)
															{
																borderColorofUser = "green";
															}
															else
															{
																borderColorofUser = "#fff";
															}
															let check = data[i].check_status;
															let color = "";
															let text_color = "";
															let diff_time = "";
															if(check.trim() =="checked")
															{
																color = "deeppink";
																let checkedNumberPre = $(".TotalChecked").html();
																let checkedNumberPost = Number(checkedNumberPre)+1;
																$(".TotalChecked").html(checkedNumberPost);
																let remaining = Number(data.length)-Number(checkedNumberPost);
																$(".TotalRemainingPatients").html(remaining);
															}
															else
															{
																color = "yellow";
															}
															let checked_time = "";
															
															if(data[i].checked_time == null)
															{
																checked_time = "<span style='color:#fff'>Not yet</span>";
															}
															else
															{
																let checked_time_parts = data[i].checked_time.split(":");
																checked_time = checked_time_parts[0]+":"+checked_time_parts[1];
																let d_one = appointment_date+" "+checked_time;
																let checked_at_parts = data[i].checked_at.split(":");
																let check_at_two = checked_at_parts[0]+":"+checked_at_parts[1];
																let d_two = appointment_date+" "+check_at_two;
		
																let date2 = new Date(d_one);
																let date1 = new Date(d_two);
		
																let diff = date2.getTime(d_two) - date1.getTime();
																if(diff <0)
																{
																	text_color = "green";
																}
																else
																{
																	text_color = "red";
																}
		
																let msec = diff;
																let hh = Math.floor(msec / 1000 / 60 / 60);
																msec -= hh * 1000 * 60 * 60;
																let mm = Math.floor(msec / 1000 / 60);
																// msec -= mm * 1000 * 60;
																// let ss = Math.floor(msec / 1000);
																// msec -= ss * 1000;
		
																diff_time = "("+hh + ":" + mm+")";
		
															}
															let checked_at_parts = data[i].checked_at.split(":");
															let check_at = checked_at_parts[0]+":"+checked_at_parts[1];
		
		
															let display = "";
															if(i == data.length-1)
															{
																display = "none";
															}
															else
															{
																display = "inline";
															}
															let status = `<div class="mx-auto">
															<div class="d-flex">
																<div class="px-2">
																	<span style="color:yellow">${check_at}</span>
																</div>
																<div class=" d-flex flex-column justify-content-center align-items-center">
																	
																	<div class="d-flex  animate__animated animate__zoomIn justify-content-center align-items-center" style="border:2px solid ${borderColorofUser}; width:30px;height:30px;border-radius:50%;">
																		<div class="checkOrNot" style="width:15px;height:15px;background-color:${color};border-radius:50%">
																		</div>
																	</div>
																	<div class="patientsLinker animate__animated animate__zoomIn" style="width:7px;height:50px;background-color:pink;display:${display}">
																	</div>
																</div>
																<div class="px-2">
																	<span style="color:blue">${checked_time}</span>
																	<span style="color:${text_color}">${diff_time}</span>
																	
																</div>
															</div>
														</div>`;
														document.querySelector(".trackInner").innerHTML += status;
														}
													});
												});
												
											}
											else
											{
												alert("Opps, ... Something went wrong!!")
											}
										}
									});
								}
							});
							
						});
					});
					

				}
			}
		});
	});
}

$(document).ready(function(){
	$("#new_password").on("keyup",function(){
		var password = $(this);
		var pass_value = document.getElementById("new_password").value;
		if(pass_value == "")
			{
				$("#repeat_password").attr("disabled","disabled");
				$(this).css("border","1px solid red");
				$("#repeat_password").val("");
			}
		else
			{
				if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
					{
						$(this).css("border","1px solid #ccc");
						$("#repeat_password").removeAttr("disabled");
						$(".change_btn").attr("disabled","disabled");
						$("#repeat_password").on("keyup",function(){
							if($(this).val() == $("#new_password").val())
								{
									if($("#old_password").val() != "")
										{
											$(".change_btn").removeAttr("disabled");
											$(this).css("border","1px solid #ccc");
											if($("#old_password").css("border","1px solid #ccc"));
										}
									else
										{
											$("#old_password").css("border","1px solid red");
											$("#old_password").on("keyup",function(){
												if($(this).val() != "")
													{
														if($("#repeat_password").val() == $("#new_password").val())
															{
																$(".change_btn").removeAttr("disabled");
																$("#repeat_password").css("border","1px solid #ccc");
															}
														else
															{
																$(".change_btn").attr("disabled","disabled");
																$("#repeat_password").css("border","1px solid red");
															}
													}
												else
													{
														$(".change_btn").attr("disabled","disabled");
													}					
											});
										}
								}
							else
								{
									$(this).css("border","1px solid red");
									$(".change_btn").attr("disabled","disabled");
								}
						});
					}
				else
					{
						$(this).css("border","1px solid red");
						$("#repeat_password").attr("disabled","disabled");
						$("#repeat_password").val("");
						$(".change_btn").attr("disabled","disabled");
					}
			}
	});
});














// JavaScript Document
$(document).ready(function(){
	$("#doctor").on("keyup",function(){
		$(".doctor_list_box").html("");
		var val = $(this).val();
		if(val.length > 1)
			{
				$.ajax({
					type : "POST",
					url : "php/doctor_search_by_name.php",
					data : {
						val : val,
					},
					success : function(response){
						if(response.trim() == "not found")
						{
							//alert("user Not Found")	
						}
						else
							{
								var json_response = JSON.parse(response);
								var i,j;
								$(".doctor_list_box").html("");
								for(i=0;i<json_response.length;i++)
									{
										var json_response = JSON.parse(response);
										var li = document.createElement("LI");
										li.className = "list-group-item py-1 doctor_name";
										li.innerHTML = json_response[i];										
										$(".doctor_list_box").append(li);
									}
								$(".doctor_name").click(function(){									
									$("#doctor").val($(this).html());
									$(".doctor_list_box").hide(100,function(){
										var doctor_name = $("#doctor").val();
										$(".booking-card").hide(100);
										$.ajax({
											type : "POST",
											url : "php/select_doctor_by_name.php",
											data : {
												name : doctor_name
											},
											success : function(response){
												var json_response = JSON.parse(response);
												var i;
												$(".doctors").html("");
												$(".search_btn").html("Search");
												$(".search_btn").removeAttr("disabled");
												if(response.trim() == "No doctor found")
													{
														var head = document.createElement("H4");
														head.innerHTML = "No Doctor found";
													}
												if(json_response.length > 0)
													{
														for(i=0;i<json_response.length;i++)
														{
															var parent_div = document.createElement("DIV");
															parent_div.className = "doctor_item mb-5 p-3 d-flex flex-column align-items-center";
															var img = document.createElement("IMG");
															img.src = "images/doctor_logo.png";
															img.style.width = "50px";
															img.style.height = "50px";
															var heading = document.createElement("H5");
															heading.className = "py-1 text-primary";
															heading.innerHTML = json_response[i][0];
															var para_1 = document.createElement("P");
															para_1.className = "p-0 m-0";
															para_1.innerHTML = json_response[i][3];
															var para_2 = document.createElement("P");
															para_2.className = "p-0 m-0 mb-2";
															para_2.innerHTML = json_response[i][2];
															var btn = document.createElement("BUTTON");
															btn.className = "btn text-center check_btn";
															btn.setAttribute("data-email",json_response[i][1]);
															var icon = document.createElement("I");
															icon.className = "fa fa-hand-o-right";
															icon.style.fontSize = "25px";
															btn.append(icon);
															btn.innerHTML += " Check Availability";
															parent_div.append(img);
															parent_div.append(heading);
															parent_div.append(para_1);
															parent_div.append(para_2);
															parent_div.append(btn);
															$(".doctors").append(parent_div);
														}
													}
												$(".check_btn").each(function(){
													$(this).click(function(){
														var doctor_email = $(this).attr("data-email");
														window.location = "doctor_user_profile/doctor_user_profile.php?doctor_email="+doctor_email;
													});
												});
											}
											
										});
									})
								});
								
							}						
					}
				});
			}
		
	});
});
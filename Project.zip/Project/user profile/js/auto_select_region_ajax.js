// JavaScript Document
$(document).ready(function(){
	$.ajax({
		type : "POST",
		url : "php/auto_select_region.php",
		beforeSend : function(){
//			$("#select_region").attr("disabled","disabled");
			
		},
		success : function(response){
			
			var json_response = JSON.parse(response);
			var region_obj = Object.values(json_response);
			var i;
			for(i=0;i<region_obj.length;i++)
				{
					var option = document.createElement("OPTION");
					option.innerHTML = region_obj[i];
					option.className = "dropdown-item";
					$("#select_region").append(option);
				}
			
		}
	});
});	
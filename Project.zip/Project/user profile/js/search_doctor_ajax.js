// JavaScript Document
$(document).ready(function(){
	$("#select_region").on("input",function(){
		if($(this).val() == "Select Region")
			{
				//$("#specialization").attr("disabled","disabled");
				$(".search_btn").attr("disabled","disabled");
			}
		else
			{
				//$("#specialization").removeAttr("disabled");
				$.ajax({
					type : "POST",
					url : "php/auto_select_special.php",
					data : {
						region : $(this).val()
					},
					success : function(response){
						var json_response = JSON.parse(response);
						var special_obj = Object.values(json_response);
						var i;
						var option = $("#specialization option");
						for(i=1;i<+ option.length;i++)
							{
								option[i].remove();
							}
						for(i=0;i<special_obj.length;i++)
							{
								var option = document.createElement("OPTION");
								option.innerHTML = special_obj[i];
								option.className = "dropdown-item";
								$("#specialization").append(option);
							}
							//$(".search_btn").removeAttr("disabled");
							$(".search_btn").click(function(e){
								e.preventDefault();
								if($("#specialization").val() != "Select Specialization")
									{
										var region = $("#select_region").val();
										var specialization = $("#specialization").val();

										$.ajax({
											catch : false,
											type : "POST",
											url : "php/search_doctor.php",
											data : {
												region : btoa(region),
												specialization : btoa(specialization)
											},
											beforeSend : function(){
												$(".search_btn").html("Please Wait ...");
												$(".search_btn").attr("disabled","disabled");
											},
											success : function(response){
												var json_response = JSON.parse(response);
												var i;
												$(".doctors").html("");
												$(".search_btn").html("Search");
												$(".search_btn").removeAttr("disabled");
												if(response.trim() == "No doctor found")
													{
														var head = document.createElement("H4");
														head.innerHTML = "No Doctor found";
													}
												if(json_response.length > 0)
													{
														for(i=0;i<json_response.length;i++)
														{
															var parent_div = document.createElement("DIV");
															parent_div.className = "doctor_item mb-5 p-3 d-flex flex-column align-items-center";
															var img = document.createElement("IMG");
															img.src = "images/doctor_logo.png";
															img.style.width = "50px";
															img.style.height = "50px";
															var heading = document.createElement("H5");
															heading.className = "py-1 text-primary";
															heading.innerHTML = json_response[i][0];
															var para_1 = document.createElement("P");
															para_1.className = "p-0 m-0";
															para_1.innerHTML = json_response[i][3];
															var para_2 = document.createElement("P");
															para_2.className = "p-0 m-0 mb-2";
															para_2.innerHTML = json_response[i][2];
															var btn = document.createElement("BUTTON");
															btn.className = "btn text-center check_btn";
															btn.setAttribute("data-email",json_response[i][1]);
															var icon = document.createElement("I");
															icon.className = "fa fa-hand-o-right";
															icon.style.fontSize = "25px";
															btn.append(icon);
															btn.innerHTML += " Check Availability";
															parent_div.append(img);
															parent_div.append(heading);
															parent_div.append(para_1);
															parent_div.append(para_2);
															parent_div.append(btn);
															$(".doctors").append(parent_div);
														}
													}
												$(".check_btn").each(function(){
													$(this).click(function(){
														var doctor_email = $(this).attr("data-email");
														window.location = "doctor_user_profile/doctor_user_profile.php?doctor_email="+doctor_email;
													});
												});
											},
										});
										
									}
								else
									{
										alert("not selected")
									}
							});
					}
				});
			}
	})
});
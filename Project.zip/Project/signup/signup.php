<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title>Signup</title>
<link rel="icon" href="images/logo.png" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
    <link href="https://fonts.googleapis.com/css?family=Righteous&display=swap|PT+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/ajax_password_request.js"></script>
	<script src="js/show_password.js"></script>
	<script src="js/ajax_email_check.js"></script>
	<script src="js/ajax_sign_up.js"></script>
    <script src="js/ajax_activate.js"></script>
    <style>
        <?php require_once("../assest/css/header.php") ?>
        <?php require_once("../assest/css/footer.php") ?>
    </style>
</head>
<body>
	
	<div>
    <?php require_once("../assest/html/header_one.php") ?>
        <div class="container-fluid main-form-con">
            
            <div class="back_position">
                <h1>Signup Here</h1>
                <hr style="width:30%;text-align: center;">
            <div class="form-con">
                <form id="form">
                    <div class="form-group">
                        <label for="name" class="text-dark">Name<sup style="color:red">*</sup></label>
                        <input type="text" name="name" id="name" class="form-control "  />
                    </div>
                    
                    <div class="form-group">
                        <label for="number" class="text-dark">Contact Number</label>
                        <input type="number" name="number" class="form-control" id="contact_number" />
                    </div>
                    <div class="form-group">
                        <label for="locality" class="text-dark">Locality</label>
                        <input type="text" name="locality" class="form-control" id="locality"/>
                    </div>

                    <div class="form-group">
                        <label for="login_as" class="text-dark">Sign up as<sup style="color:red">*</sup></label>
                        <select name="login_as" id="login_as" class="form-control">
                            <option>None</option>
                            <option>User/Patient</option>
                            <option>Doctor</option>
                            <!-- <optopn>Employee</optopn> -->
                        </select>
                    </div>
                    <div class="appear">

                    </div>
                    
                    
                    <div class="form-group">
                        <label for="password">Password<sup style="color:red">*</sup></label>
                        <div id="password_box">
                            <input type="password" name="password" id="password"  class="form-control"/>
                            <i class="fa fa-eye show_icon" style="font-size:18px"></i>
                        </div>
                        
                    </div>
                    <p class="float-left">CLICK GENERATE TI IMPROVE SECURITY</p>
                    <button class="btn btn-warning text-light mb-3 float-right generate_btn">Generate</button>


                    <div class="custom-contron custom-switch mb-3">
                        <input type="checkbox" name="accept" class="custom-control-input" id="accept" />
                            <label for="accept" class="custom-control-label">I Accept The <a href="javascript:void(0)" class="termsNotices">Terms and Conditions</a></label>
                        
                    </div>
                    <button class="btn btn-success text-light signup_btn" type="submit">Sign up</button>
                    
                </form>
                <div class="signup_notice">
                        
                    </div>
                <div class="px-2 mt-3 d-none activator">
                    <span>Check Your Email to Get Actovation Code</span>
                    <input type="number" name="code" id="code" class="form-control my-3" placeholder="Activation Code" />
                    <button class="btn btn-dark activate_btn">Activate Now</button>
                
                </div>
            </div>

            </div>
            
        </div>
        <?php require_once("../assest/html/footer.php") ?>
    </div>

</body>
</html>
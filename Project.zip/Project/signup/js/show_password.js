// JavaScript Document
$(document).ready(function(){
	$(".show_icon").click(function(){
		if($("#password").attr("type") == "password")
			{
				$("#password").attr("type","text");
				$(this).css("color","#000");
			}
		else
			{
				$("#password").attr("type","password");
				$(this).css("color","#ccc"); 
			}
	});
});
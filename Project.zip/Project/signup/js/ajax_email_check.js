// JavaScript Document
// $(document).ready(function(){
// 	$("#login_as").on("change",function(){
// 		$("#email").on("change",function(){
// 		if($(this).val() != "")
// 			{
// 				$.ajax({
// 					type : "POST",
// 					url : "../php/check_user_emai.php",
					
// 					data : {
// 						email : btoa($(this).val()),
// 						login_as : btoa($("#login_as").val()),
// 					},
// 					beforeSend : function(){
// 						$(".email_loader").removeClass("d-none");
						
// 					},
// 					success : function(response){
// 						if(response.trim() == "user found")
// 							{
// 								$(".email_loader").removeClass("fa fa-circle-o-notch fa-spin");
// 								$(".email_loader").removeClass("fa fa-check-circle");
// 								$(".email_loader").addClass("fa fa-times-circle text-warning");
// //								$(".signup_btn").attr("disabled","disabled");
// 							}
// 						else
// 							{
// 								$(".email_loader").removeClass("fa fa-circle-o-notch fa-spin");
// 								$(".email_loader").removeClass("fa fa-times-circle");
// 								$(".email_loader").addClass("fa fa-check-circle text-primary");
// //								$(".signup_btn").removeAttr("disabled");
								
// 							}
// 					}
// 				});
// 			}
// 	})
// 	})
// });


// JavaScript Document
$(document).ready(function(){
	$(".activate_btn").click(function(e){
		e.preventDefault();
		var code = btoa($("#code").val());
		var email = btoa($("#email").val());
		var login_as = btoa($("#login_as").val());
		var login_as_val = $("#login_as").val();
		$.ajax({
			type : "POST",
			url : "../php/activator.php",
			data : {
				code : code,
				email : email,
				login_as : login_as
			},
			beforeSend : function(){
				$(".activate_btn").html("Please wait ...");
				$(".activate_btn").attr("disabled","disabled");
			},
			success : function(response){
				if(response.trim() == "Users varified")
				{
					if(login_as_val == "Doctor")
						{
							window.location = "../doctor profile/doctor.php";
						}
					else
						{
							window.location = "../user profile/user.php";
						}
					
				}
				else
					{
						
						$(".activate_btn").html("Activate Now");
						$(".activate_btn").removeAttr("disabled");
						$("#code").val("");
						var notice = document.createElement("DIV");
						notice.className = "alert alert-warning";
						notice.innerHTML = "<b>Wrong activation code</b>";
						$(".signup_notice").append(notice);
						setTimeout(function(){
							$(".signup_notice").html("");
						},3000)
					}
				
				
			}
			
		});
	});
});
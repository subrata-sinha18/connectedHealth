// JavaScript Document
$(document).ready(function(){
	$(".generate_btn").click(function(e){
		e.preventDefault();
		$("#password").attr("type","txet");
		$(".show_icon").css({
			color:"#000"
		})
		$.ajax({
			type:"POST",
			url:"../php/random_passowrd.php",
			beforeSend : function(){
				$(".show_icon").removeClass("fa fa-eye");
				$(".show_icon").addClass("fa fa-circle-o-notch fa-spin")
			},
			success : function(response){
				$(".show_icon").removeClass("fa fa-circle-o-notch fa-spin")
				$(".show_icon").addClass("fa fa-eye");
				$("#password").val(response);
			}
		});
	});
});
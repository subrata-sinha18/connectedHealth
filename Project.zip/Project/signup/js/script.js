// JavaScript Document

// dynamic navbar toggler
$(document).ready(function(){
	$("#nav-icon").click(function(){
		$("#mobile-menu").collapse('toggle');
		$("#mobile-menu").addClass("animated zoomIn");
	});
});

//$(document).ready(function(){
//	var string = "APPOINTMENT";
//	var i=0;
//	if(i<string.length)
//		{
//			setInterval(function(){
//				document.querySelector(".add-head").innerHTML += string.charAt(i);
//				i++;
//			},200);
//			
//		}
//});


$(document).ready(function(){
	$("#search-icon").click(function(){
		$("#serach-input-box").collapse('toggle');
	});
	
	$("#serach-input-box").on('show.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"50px"});
	});
	
	$("#serach-input-box").on('hide.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"0"});
	});
});



$(document).ready(function(){
	$("#login_as").on("change",function(){
		if($(this).val() == "Doctor")
		{
			$(".appear").html('<div class="form-group"><label for="email" class="text-dark">Email Id<sup style="color:red">*</sup></label><div class="email_box"><input type="email" name="email" class="form-control" id="email" /><i class="fa fa-circle-o-notch fa-spin d-none email_loader" style="font-size:18px"></i></div></div><div class="form-group"><label for="login_as" class="text-dark">Select Specialization<sup style="color:red">*</sup></label><select name="login_as" id="specialization" class="form-control"><option class="dropdown-item">Select Specialization</option><option class="dropdown-item">Anesthesiologist -- Anesthesis for surgery</option><option class="dropdown-item">Cardiac Surgeon -- Specializes in surgical procedures of the heart, lungs, esophagus, and other organs</option><option class="dropdown-item">Cardiologist -- Heart disease</option><option class="dropdown-item">Cardiologist and Diabetologist -- Heart Diseases and Diabetics</option><option class="dropdown-item">Consultant Physician -- Medicine</option><option class="dropdown-item">Consultant Physician & Diabetologist -- </option><option class="dropdown-item">Cosmetic Surgeon -- Skin, Plastic Surgery </option><option class="dropdown-item">Dentist -- Teeth doctor</option><option class="dropdown-item">Dermatologist -- Skin doctor</option><option class="dropdown-item">Diabetologist -- Diabetes</option><option class="dropdown-item">Endocrinologist -- Thyroid disease</option><option class="dropdown-item">ENT -- Ear, Nose, Throat</option><option class="dropdown-item">For Test -- Testing Purpose</option><option class="dropdown-item">Gastroenterologist -- Diseases of the digestive system</option><option class="dropdown-item">Gastroenterologist & Hepatologist -- Acid Reflux, Indigestion and Vomiting. Peptic Ulcer Disease, Liver , Gallbladder etc</option><option class="dropdown-item">General & Laparoscopic surgery -- </option><option class="dropdown-item">General Physican -- Medicine</option><option class="dropdown-item">General Surgeon -- Surgery</option><option class="dropdown-item">Gynaecologist -- Pregnancy, Childbirth, Woman Health etc</option><option class="dropdown-item">Hepatologist -- Liver Expert</option><option class="dropdown-item">Homeopathy -- Homeopathy doctor</option><option class="dropdown-item">Nephrologist -- Kidney disease</option><option class="dropdown-item">Neurologist -- Brain, Nervous system</option><option class="dropdown-item">Neuropsychiatrist -- Brains, Nerves, Mental disorders etc</option><option class="dropdown-item">Neurosurgeon -- Brain, Nerves</option><option class="dropdown-item">Oncologist -- Cancer doctor</option><option class="dropdown-item">SpecializatiOphthalmologist -- Eye doctoron</option><option class="dropdown-item">Optometrist -- For Defects in Vision and Eye Disorders</option><option class="dropdown-item">Orthodontist -- Teeth</option><option class="dropdown-item">Orthopaedic -- Bone, fractures, back-pain</option><option class="dropdown-item">Pathologist -- Blood test, urine test etc</option><option class="dropdown-item">Pediatrician -- Child doctor</option><option class="dropdown-item">Physiotherapist --  Physical therapy</option><option class="dropdown-item">Psychiatrist -- Mental disorders</option><option class="dropdown-item">Radiologist -- X-ray, MRI etc</option><option class="dropdown-item">Rheumatologist -- Rheumatology</option><option class="dropdown-item">Rheumatology -- Arthritis, Joint Point & Nerve</option><option class="dropdown-item">Urologist -- Urinary tract</option><option class="dropdown-item">Veteninary -- Animal doctor</option><optopn>Employee</optopn></select></div><div class="form-group"><label for="experience">Experience in Years</label><input type="number" name="number" id="experience"  class="form-control"/></div>')
		}
		else if($(this).val() == "User/Patient")
		{
			$(".appear").html('<div class="form-group"><label for="email" class="text-dark">Email Id<sup style="color:red">*</sup></label><div class="email_box"><input type="email" name="email" class="form-control" id="email" /><i class="fa fa-circle-o-notch fa-spin d-none email_loader" style="font-size:18px"></i></div></div>');
		}
		else
			{
				$(".appear").html("");
			}
	})
});

$(document).ready(function(){
	$(".login").each(function(){
		$(this).on("click",function(){
			window.location = "../login/login.php";
		})
	});
});
$(document).ready(function(){
	$(".signup").each(function(){
		$(this).on("click",function(){
			window.location = "signup.php";
		})
	});
});


// $(document).ready(function(){
// 	$("#name").on("keyup",function(){
// 		var name_val = $(this).val();
// 		var name = $(this);
// 		if(name_val == "" || name_val.match(/[0-9]/g) || name_val.match(/[!||@||#||%||$||^||&||*||(||)||_||_||-||=||,||.||<||>||?]/g))
// 			{
// 				$(this).css("border","1px solid red");
// 				$("#contact_number").attr("disabled","disabled");
// 			}
// 		else
// 			{
// 				$(this).css("border","1px solid #ccc");
// 				$("#contact_number").removeAttr("disabled");
// 				$("#contact_number").on("keyup",function(){
// 					var contact_val = $(this).val();
// 					var contact = $(this);
// 					if(contact_val == "" || contact_val.length != 10)
// 						{
// 							$(this).css("border","1px solid red");
// 							$("#login_as").attr("disabled","disabled");
// 						}
// 					else
// 						{
// 							$(this).css("border","1px solid #ccc");
// 							$("#login_as").removeAttr("disabled");
// 								$("#login_as").on("change",function(){
// 									var login_as = $(this);
// 									if($(this).val() == "None")
// 										{
// 											$("#email").attr("disabled","disabled");
// 										}
// 									else if($(this).val() == "Doctor")
// 										{
// 											$("#email").removeAttr("disabled");
// 											$("#email").on("keyup",function(){
// 												var email = $(this);
// 												var email_value = document.getElementById("email").value;
// 												var email_input = document.getElementById("email");
// 												if(email_value == "" || email_value.charAt(0).match("@"))
// 													{
// 														$("#specialization").attr("disabled","disabled");
// 													}
// 												else
// 													{
// 														if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 															{
// 																$("#specialization").removeAttr("disabled");
// 																$("#specialization").on("change",function(){
// 																	var special = $(this);
// 																	if($(this).val() == "Select Specialization")
// 																		{
// 																			$("#password").attr("disabled","disabled");
// 																		}
// 																	else
// 																		{
// 																			$("#password").removeAttr("disabled","disabled");
// 																			$("#password").on("keyup",function(){
// 																				var password = $(this);
// 																				var pass_value = document.getElementById("password").value;
// 																				if(pass_value == "")
// 																					{
// 																						$(".signup_btn").attr("disabled","disabled");
// 																					}
// 																				else
// 																					{
// 																						if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 																							{
// 																								$(".signup_btn").removeAttr("disabled");
// 																							}
// 																						else
// 																							{
// 																								$(".signup_btn").attr("disabled","disabled");
// 																							}
// 																					}


// 																			});
// 																		}
// 																})
// 															}
// 														else
// 															{
// 																$("#specialization").attr("disabled","disabled");
// 															}
// 													}	
// 											});
// 										}
// 									else
// 										{
// 											$("#email").removeAttr("disabled");
// 											$("#email").on("keyup",function(){
// 												var email_value = document.getElementById("email").value;
// 												if(email_value == "" || email_value.charAt(0).match("@"))
// 													{
// 														$("#password").attr("disabled","disabled");
// 													}
// 												else
// 													{
// 														if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 															{
																
// 																$("#password").removeAttr("disabled","disabled");
// 																$("#password").on("keyup",function(){
// 																	var password = $(this);
// 																	var pass_value = document.getElementById("password").value;
// 																	if(pass_value == "")
// 																		{
// 																			$(".signup_btn").attr("disabled","disabled");
// 																		}
// 																	else
// 																		{
// 																			if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 																				{
// 																					$(".signup_btn").removeAttr("disabled");
// 																				}
// 																			else
// 																				{
// 																					$(".signup_btn").attr("disabled","disabled");
// 																				}
// 																		}
// 																});
// 															}
// 														else
// 															{
// 																$("#password").attr("disabled","disabled");
// 															}
// 													}
// 											});
// 										}
// 								});
// 						}
// 				});
// 			}
// 	});
// });











// function nameValidation(){
// 	$(document).ready(function(){
// 		$("#name").on("keyup",function(){
// 			var name_val = $(this).val();
// 			var name = $(this);
			
// 			if(name_val == "" || name_val.match(/[0-9]/g) || name_val.match(/[!||@||#||%||$||^||&||*||(||)||_||_||-||=||,||.||<||>||?]/g))
// 			{
// 				$(this).css("border","1px solid red");
// 				$("#contact_number").attr("disabled","disabled");
// 				contact();
				
// 			}
// 			else
// 			{
// 				$(this).css("border","1px solid #ccc");
// 				$("#contact_number").removeAttr("disabled");
				
				 
// 			}
				
// 		});
// 	});
// }
// nameValidation();

// function contact(){
// 	var contact_val = document.querySelector("#contact_number").value;
// 	var contact = document.querySelector("#contact_number");
// 	if(contact_val == "" || contact_val.length != 10)
// 	{
// 		$("#contact_number").css("border","1px solid red");
// 		$("#login_as").attr("disabled","disabled");
// 	}
// 	else
// 	{
// 		$("#contact_number").css("border","1px solid #ccc");
// 		$("#contact_number").removeAttr("disabled");
// 		$("#login_as").removeAttr("disabled");
// 	}
// }

// function contactValidation(){
// 	$(document).ready(function(){
// 		$("#contact_number").on("keyup",function(){
// 			var contact_val = document.querySelector("#contact_number").value;
// 			var contact = document.querySelector("#contact_number");
// 			if(contact_val == "" || contact_val.length != 10)
// 			{
// 				$(this).css("border","1px solid red");
				
// 				$("#login_as").attr("disabled","disabled");
// 				login();
// 			}
// 			else
// 			{
// 				$(this).css("border","1px solid #ccc");
// 				// $("#contact_number").removeAttr("disabled");
// 				$("#login_as").removeAttr("disabled");
// 			}
				
// 		});
// 	});
// }
// contactValidation();

// function login(){
// 	var login_val = document.querySelector("#login_as").value;
// 	var login = document.querySelector("#login_as");
// 	if(login_val == "None")
// 	{
// 		$("#email").attr("disabled","disabled");
// 	}
// 	else
// 	{
// 		$("#login_as").removeAttr("disabled");
// 		$("#email").removeAttr("disabled");
// 		emailValidation();
// 		specializationlValidation();
// 	}
// }

// function loginValidation(){
// 	$(document).ready(function(){
// 		$("#login_as").on("change",function(){
// 			$("#password").attr("disabled","disabled");
// 			var login_val = $(this).val();
// 			var login = $(this);
// 			if($(this).val() == "None")
// 			{
// 				$("#email").attr("disabled","disabled");
// 				email();
// 			}
// 			else if($(this).val() == "Doctor")
// 			{
// 				$("#login_as").removeAttr("disabled");
// 				$("#email").removeAttr("disabled");
// 				emailValidation();
// 				specializationlValidation();
// 			}
// 			else
// 			{
// 				$("#login_as").removeAttr("disabled");
// 				$("#email").removeAttr("disabled");
// 				userEmailValidation();
// 			}			
// 		});
// 	});
// }
// loginValidation();

// function userEmailValidation(){
// 	$(document).ready(function(){
// 		$("#email").on("keyup",function(){
// 			var email_value = $(this).val();
// 			var email = $(this);
// 			if(email_value == "" || email_value.charAt(0).match("@"))
// 			{
// 				$(this).css("border","1px solid red");
// 				$("#password").attr("disabled","disabled");
// 			}
// 			else
// 			{
// 				if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 				{ 
// 					$(this).css("border","1px solid #ccc");
					
// 					$("#password").removeAttr("disabled");
					
// 				}
// 				else
// 				{
// 					$(this).css("border","1px solid red");
// 					$("#password").attr("disabled","disabled");
					
// 				}
				
// 			}				
// 		});
// 	});
// };


// function email(){
// 	var email_value = document.querySelector("#email").value;
// 	var email = document.querySelector("#email");
// 	if(email_value == "" || email_value.charAt(0).match("@"))
// 	{
// 		$("#email").css("border","1px solid red");
// 		$("#specialization").attr("disabled","disabled");
// 	}
// 	else
// 	{
// 		if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 		{ 
// 			$(this).css("border","1px solid #ccc");
// 			$("#email").removeAttr("disabled");
// 			$("#specialization").removeAttr("disabled");
// 		}
// 		else
// 		{
// 			$("#email").css("border","1px solid red");
// 			$("#specialization").attr("disabled","disabled");
// 		}
// 	}
// }

// function emailValidation(){
// 	$(document).ready(function(){
// 		$("#email").on("keyup",function(){
// 			var email_value = $(this).val();
// 			var email = $(this);
// 			if(email_value == "" || email_value.charAt(0).match("@"))
// 			{
// 				$(this).css("border","1px solid red");
// 				$("#specialization").attr("disabled","disabled");
// 			}
// 			else
// 			{
// 				if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 				{ 
// 					$(this).css("border","1px solid #ccc");
					
// 					$("#specialization").removeAttr("disabled");
					
// 				}
// 				else
// 				{
// 					$(this).css("border","1px solid red");
// 					$("#specialization").attr("disabled","disabled");
// 					special();
// 				}
				
// 			}				
// 		});
// 	});
// };

// function special(){
// 	if($("#specialization").val() == "Select Specialization")
//  	{
//  		$("#password").attr("disabled","disabled");
// 	}
// 	else
// 	{
// 		$("#specialization").removeAttr("disabled");
// 		$("#password").removeAttr("disabled");
// 	} 
// }

// function specializationlValidation(){
// 	$(document).ready(function(){
		
// 		$("#specialization").on("change",function(){
// 			if($(this).val() == "Select Specialization")
//  			{
// 				 $("#password").attr("disabled","disabled");
// 				 password();
// 			}
// 			else
// 			{
// 				$("#password").removeAttr("disabled");
// 			} 
							
// 		});
// 	});
// };

// function password(){
// 	var password = $("#password");
// 	var pass_value = $("#password").val();
// 	if(pass_value == "")
// 	{
// 		$(".signup_btn").attr("disabled","disabled");
// 	}
// 	else
// 	{
// 		if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 		{
// 			$("#password").removeAttr("disabled");
// 			 $(".signup_btn").removeAttr("disabled");
// 		}
// 		else
// 		{
// 			$(".signup_btn").attr("disabled","disabled");
// 		}
// 	}
// }
// function passwordlValidation(){
// 	$(document).ready(function(){
// 		$("#password").on("keyup",function(){
// 			var password = $(this);
// 			var pass_value = $(this).val();
// 			if(pass_value == "")
// 			{
// 				$(".signup_btn").attr("disabled","disabled");
// 			}
// 			else
// 			{
// 				if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 				{
// 					// $(".signup_btn").removeAttr("disabled");
// 				}
// 				else
// 				{
// 					$(".signup_btn").attr("disabled","disabled");
// 				}
// 			}
// 		})
// 	});
// };
// passwordlValidation();




// function checkForm(){
// 	$(document).ready(function(){
// 		$("#accept").on("change",function(){
// 			if($(this).prop("checked") == true)
// 			{
// 				alert();
// 			}
// 		});
// 	});
// }
// checkForm();














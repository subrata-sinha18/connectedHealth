// JavaScript Document
$(document).ready(function(){
	$(".signup_btn").click(function(e){
		e.preventDefault();
		let name_val = $("#name").val();
		
		if(name_val == "" || name_val.match(/[0-9]/g) || name_val.match(/[!||@||#||%||$||^||&||*||(||)||_||_||-||=||,||.||<||>||?]/g))
		{
			$("#name").css("border","1px solid red");
		}
		else
		{
			$("#name").css("border","1px solid #ccc");
			let contact_val = $("#contact_number").val();
			if(contact_val == "" || contact_val.length != 10)
			{
				$("#contact_number").css("border","1px solid red");
			}
			else
			{
				$("#contact_number").css("border","1px solid #ccc");
				if($("#locality").val() == "")
				{
					$("#locality").css("border","1px solid red");
				}
				else
				{
					$("#locality").css("border","1px solid #ccc");
					let logIn_val = $("#login_as").val();
					if(logIn_val == "None")
					{
						$("#login_as").css("border","1px solid red");
					}
					else if(logIn_val == "Doctor")
					{
						$("#login_as").css("border","1px solid #ccc");
						var email_value = $("#email").val();
						if(email_value == "" || email_value.charAt(0).match("@"))
						{
							$("#email").css("border","1px solid red");
						}
						else
						{
							if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
							{
								$("#email").css("border","1px solid #ccc");
								if($("#specialization").val() == "Select Specialization")
								{
									$("#specialization").css("border","1px solid red");
								}
								else
								{
									$("#specialization").css("border","1px solid #ccc");
									var pass_value = $("#password").val();
									if(pass_value == "")
									{
										$("#password").css("border","1px solid red");
									}
									else
									{
										if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
										{
											$("#password").css("border","1px solid #ccc");
											if($('#accept').prop("checked") == true){
												signUp();
											}
											else if($('#accept').prop("checked") == false){
												alert("Plaese check out terms & conditions");
											}
											//signUp();
										}
									else
										{
											$("#password").css("border","1px solid red");
										}
									}
								}
							}
							else
							{
								$("#email").css("border","1px solid red");
							}
						}
					}
					else
					{
						let email_value = $("#email").val();
						if(email_value == "" || email_value.charAt(0).match("@"))
						{
							$("#email").css("border","1px solid red");
						}
						else
						{
							if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
							{
								$("#email").css("border","1px solid #ccc");
								var pass_value = $("#password").val();
								if(pass_value == "")
								{
									$("#password").css("border","1px solid red");
								}
								else
								{
									if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
									{
										$("#password").css("border","1px solid #ccc");
										if($('#accept').prop("checked") == true){
											signUp();
										}
										else if($('#accept').prop("checked") == false){
											alert("Plaese check out terms & conditions");
										}
									}
								else
									{
										$("#password").css("border","1px solid red");
									}
								}
							}
							else
							{
								$("#email").css("border","1px solid red");
							}
						}		
					}
				}
			}
		}
	});
})





// $(document).ready(function(){
// 	$("#name").on("keyup",function(){
// 		var name_val = $(this).val();
// 		var name = $(this);
// 		if(name_val == "" || name_val.match(/[0-9]/g) || name_val.match(/[!||@||#||%||$||^||&||*||(||)||_||_||-||=||,||.||<||>||?]/g))
// 			{
// 				$(this).css("border","1px solid red");
// 			}
// 		else
// 			{
// 				$(this).css("border","1px solid #ccc");
// 				$("#contact_number").on("keyup",function(){
// 					var contact_val = $(this).val();
// 					var contact = $(this);
// 					if(contact_val == "" || contact_val.length != 10)
// 						{
// 							$(this).css("border","1px solid red");
// 						}
// 					else
// 						{
// 							$(this).css("border","1px solid #ccc");
// 								$("#login_as").on("change",function(){
// 									var login_as = $(this);
// 									if($(this).val() == "None")
// 										{
// 											//$("#email").css("border","1px solid red");
// 											$(this).css("border","1px solid red");
// 										}
// 									else if($(this).val() == "Doctor")
// 										{
// 											$(this).css("border","1px solid red");
// 											$("#email").on("keyup",function(){
// 												var email = $(this);
// 												var email_value = document.getElementById("email").value;
// 												var email_input = document.getElementById("email");
// 												if(email_value == "" || email_value.charAt(0).match("@"))
// 													{
// 														//$("#specialization").attr("disabled","disabled");
// 													}
// 												else
// 													{
// 														if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 															{
// 																//$("#specialization").removeAttr("disabled");
// 																$("#specialization").on("change",function(){
// 																	var special = $(this);
// 																	if($(this).val() == "Select Specialization")
// 																		{
// 																			//$("#password").attr("disabled","disabled");
// 																		}
// 																	else
// 																		{
// 																			//$("#password").removeAttr("disabled","disabled");
// 																			$("#password").on("keyup",function(){
// 																				var password = $(this);
// 																				var pass_value = document.getElementById("password").value;
// 																				if(pass_value == "")
// 																					{
// 																						//$(".signup_btn").attr("disabled","disabled");
// 																					}
// 																				else
// 																					{
// 																						if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 																							{
// 																								//$(".signup_btn").removeAttr("disabled");
// 																								signUp();
// 																							}
// 																						else
// 																							{
// 																								//$(".signup_btn").attr("disabled","disabled");
// 																							}
// 																					}


// 																			});
// 																		}
// 																})
// 															}
// 														else
// 															{
// 																//$("#specialization").attr("disabled","disabled");
// 															}
// 													}	
// 											});
// 										}
// 									else
// 										{
// 											//$("#email").removeAttr("disabled");
// 											$("#email").on("keyup",function(){
// 												var email_value = document.getElementById("email").value;
// 												if(email_value == "" || email_value.charAt(0).match("@"))
// 													{
// 														//$("#password").attr("disabled","disabled");
// 													}
// 												else
// 													{
// 														if(email_value.match("@gmail.com") || email_value.match("@rediffmail.com") || email_value.match("@yahoo.com"))
// 															{
																
// 																//$("#password").removeAttr("disabled","disabled");
// 																$("#password").on("keyup",function(){
// 																	var password = $(this);
// 																	var pass_value = document.getElementById("password").value;
// 																	if(pass_value == "")
// 																		{
// 																			//$(".signup_btn").attr("disabled","disabled");
// 																		}
// 																	else
// 																		{
// 																			if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
// 																				{
// 																					//$(".signup_btn").removeAttr("disabled");
// 																					signUp();
// 																				}
// 																			else
// 																				{
// 																					//$(".signup_btn").attr("disabled","disabled");
// 																				}
// 																		}
// 																});
// 															}
// 														else
// 															{
// 																//$("#password").attr("disabled","disabled");
// 															}
// 													}
// 											});
// 										}
// 								});
// 						}
// 				});
// 			}
// 	});
// });




let signUp = () =>{
	$.ajax({
		type : "POST",
		url : "../php/sign_up.php",
		data : {
			name : btoa($("#name").val()),
			email : btoa($("#email").val()),
			contact_number : btoa($("#contact_number").val()),
			locality : btoa($("#locality").val()),
			login_as : btoa($("#login_as").val()),
			specialization : btoa($("#specialization").val()),
			experience : btoa($("#experience").val()),
			password : btoa($("#password").val()),
		},
		beforeSend : function(){
			$(".signup_btn").html("Processing Please Wait ...");
			$(".signup_btn").attr("disabled","disabled");
		},
		success : function(response){
			if(response.trim() == "sendind success")
				{
					$("form").fadeOut(500,function(){
						$(".activator").removeClass("d-none");
					});
				}
			else
				{
					
					var message = document.createElement("DIV");
					
					message.className = "alert alert-warning";
					message.innerHTML = "<b>Somethis went wrong, Please try again later</b>";
					$(".signup_notice").append(message);
					$(".signup_btn").html("Register Now");
					$("form").trigger("reset");
					$(".email_loader").addClass("d-none");
					setTimeout(function(){
						$(".signup_notice").html("");
					},2000);
				}
		}
	});
}
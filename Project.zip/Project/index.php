<?php
require("php/database.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title>Connected Health</title>
<link rel="icon" href="images/logo.png" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/main.css">
	
	<!-- <link rel="stylesheet" href="css/animate.css"> -->
	<link
    rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
	<!-- <link rel="stylesheet" href="css/jquery-ui.css"> -->
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<!-- <script src="js/jquery-ui.js"></script> -->
	<style>
		<?php require_once("assest/css/header.php") ?>
		<?php require_once("assest/css/footer.php") ?>
	</style>
</head>
<body>
	
	<div class="">
		<?php require_once("assest/html/header_one.php") ?>
		<div class="headerBottom d-flex justify-content-end p-5">
			<div class="d-flex flex-column align-items-end py-5" style="width:40%; height:100%;">
				<div class="animate__animated animate__bounceInDown	input-group w-75 position-relative mb-5 mt-4">
					<input type="email" id="select_region" name="location" placeholder="Enter Rigion" class="form-control location" />
					<div class="input-group-append">
						<span class="input-group-text bg-danger text-white">Location</span>
	
					</div>
					<div class="position-absolute d-none" style="top:40px;height:200px;width:100%;">
						<ul class="list-group locationList">
							
						  </ul>

					</div>
				</div>

				<div class="animate__animated animate__bounceInDown animate__delay-1s input-group w-75 position-relative mb-5">
					<!-- <input type="email" name="subscibe-email" placeholder="email@gmail.com" class="form-control location" /> -->
					<select name="specialization" id="specialization" class="form-control">
						<option>Select Specialization</option>
					</select>
					<div class="input-group-append">
						<span class="input-group-text bg-warning text-white">Speciazation</span>
	
					</div>
					<div class="position-absolute d-none" style="top:40px;height:200px;width:100%;">

					</div>
				</div>

				<div class="input-group w-75">
					<!-- <button class="animate__animated animate__flipInX animate__delay-2s btn btn-primary search_btn">Search</button> -->
					<!-- <div class="wrapper-inner-tab-backgrounds w-100">
						
						
						
					</div> -->
					<!-- <div class="wrapper-inner-tab-backgrounds-first" style="width:200px;height:auto;"></div> -->
					<div class="animate__animated animate__flipInX animate__delay-2s sim-button button12 m-0 p-0 bg-primary search_btn" style="width:200px;"><span>Search</span></div>
				</div>
				

			</div>

		</div>
		<div class="d-none doctorContainer">
			<div class="doctors py-5 w-100 d-flex flex-wrap justify-content-between">
							
			</div>
		</div>
		
		<!-- <div class="container-fluid p-3 p-lg-5 text-center my-bg text-white">
			<div class="input-group collapse position-absolute animated slideInRight" id="serach-input-box">
				<input type="search" class="form-control" placeholder="Search this site" />
				<div class="input-group-append">
					<buton class="btn btn-warning text-light">Search</buton>
				</div>
			</div>
			<div class="carousel slide" data-ride="carousel" id="header-slider">
				<ol class="carousel-indicators">
					<li data-target="#header-slider" data-slide-to="0" class="active"></li>
					<li data-target="#header-slider" data-slide-to="1"></li>
					<li data-target="#header-slider" data-slide-to="2"></li>
					<li data-target="#header-slider" data-slide-to="3"></li>
				</ol>
				<div class="carousel-inner">
					<div class="carousel-item active">
						<h1 class="add-head"></h1>
						<p class="add-para animated zoomIn slower">MAKE IT EASIER FOR PATIENTS</p>
						<button class="btn btn-warning text primary my-2 px-lg-5 py-lg-3 mr-lg-3 mb-lg-5 animated zoomIn slower login">START A JOURNEY</button>
						<button class="btn btn-light rext-dark my-2 px-lg-5 py-lg-3 ml-lg-3 mb-lg-5 animated zoomIn slower">VIEW ADVANTAGES</button>
					</div>
					<div class="carousel-item">
						<h1 class="first-add-head animated flip">SMS BOOKING</h1>
						<p class="add-para animated zoomIn slower">GET THE SMS OF YOUR BOOKING</p>
						<button class="btn btn-warning text primary my-2 px-lg-5 py-lg-3 mr-lg-3 mb-lg-5 animated zoomIn slower login">START A JOURNEY</button>
						<button class="btn btn-light rext-dark my-2 px-lg-5 py-lg-3 ml-lg-3 mb-lg-5 animated zoomIn slower">VIEW ADVANTAGES</button>
					</div>
					<div class="carousel-item">
						<h1 class="second-add-head animated slideInRight slower">CANCEL BOOKING</h1>
						<p class="add-para animated zoomIn slower">CANCEL YOUR BOOKING APPOINTMENT</p>
						<button class="btn btn-warning text primary my-2 px-lg-5 py-lg-3 mr-lg-3 mb-lg-5 animated zoomIn slower login">START A JOURNEY</button>
						<button class="btn btn-light rext-dark my-2 px-lg-5 py-lg-3 ml-lg-3 mb-lg-5 animated zoomIn slower">VIEW ADVANTAGES</button>
					</div>
					<div class="carousel-item">
						<h1 class="third-add-head animated fadeIn slower">GUIDE</h1>
						<p class="add-para animated zoomIn slower">GET THE COMPLETE GUIDE</p>
						<button class="btn btn-warning text primary my-2 px-lg-5 py-lg-3 mr-lg-3 mb-lg-5 animated zoomIn slower login">START A JOURNEY</button>
						<button class="btn btn-light rext-dark my-2 px-lg-5 py-lg-3 ml-lg-3 mb-lg-5 animated zoomIn slower">VIEW ADVANTAGES</button>
					</div>
				</div>
			</div>
			
		</div> -->
		<div class="main-section">
			<div class="trans p-4">
				<h2 class="text-light" style="font-family:monospace;text-align: center;">Welcome Visitor</h2>
				
				

			</div>
		</div>
		<div class="container our-story">
			<div class="row">
				<div class="col-md-12">
					<h4 class="mt-5 mb-4">OUR STORY</h4>
					<ul class="nav nav-tabs">
						<li class="nav-item"><a href="#overview" class="nav-link active" data-toggle="tab">Overview</a></li>
						<li class="nav-item"><a href="#founder" class="nav-link" data-toggle="tab">Founders</a></li>
						<li class="nav-item"><a href="#mission" class="nav-link" data-toggle="tab">Mission</a></li>		
					</ul>
					<div class="tab-content mt-5 mb-3">
						<div id="overview" class="tab-pane active animated slideInLeft faster">
							<div class="media flex-column flex-lg-row">
								<img src="images/desktop.png" alt="f" width="35%" class="mb-4 mr-4 mr-lg-2 mb-lg-0" id="desktop-img"/>
								<div class="media-content">
									<h2>Who are we?</h2>
									<p>Connected Health, a website cum family where we are connecting media between the Doctors and Patients and people as well. We provide the needy patients a platform to find their Doctors for the particular issue they have at the convenient place and convenient time at their own choice.</p>
								</div>
							</div>
						</div>
						<div id="founder" class="tab-pane animated slideInRight faster">
							<div class="d-flex flex-column flex-lg-row justify-content-around">
								<div class="card align-self-start border border-warning mx-auto mx-lg-0 mb-4 mb-lg-0" id="founder-card">
									<div class="card-body">
										<img src="images/vikash.jpg" alt="f" width="250" />
									</div>
									<div class="card-footer bg-warning text-center">
										<h5>Vikash Kumar</h5>
										<small>B.Tech 4th year</small><br>
										<small>(1607010037)</small>
									</div>
								</div>
								<div class="card align-self-start border border-warning mx-auto mx-lg-0 mb-4 mb-lg-0" id="founder-card">
									<div class="card-body">
										<img src="images/subrata.png" alt="f" width="250" />
									</div>
									<div class="card-footer bg-warning text-center">
										<h5>Subrata Sinha</h5>
										<small>B.Tech 4th year</small><br>
										<small>(1607010035)</small>
									</div>
								</div>
								<div class="card align-self-start border border-warning mx-auto mx-lg-0 mb-4 mb-lg-0" id="founder-card">
									<div class="card-body">
										<img src="images/neeraj.jpg" alt="f" width="250" />
									</div>
									<div class="card-footer bg-warning text-center">
										<h5>Neeraj Pandey</h5>
										<small>B.Tech 4th year</small><br>
										<small>(1607010020)</small>
									</div>
								</div>
									<!-- <div class="card align-self-start border border-warning mx-auto mx-lg-0 mb-4 mb-lg-0" id="founder-card">
										<div class="card-body">
											<img src="images/f.jpg" alt="f" width="250" />
										</div>
										<div class="card-footer bg-warning text-center">
											<h5>SUbrata Sinha</h5>
											<small>Founder and CEO</small>
										</div>
									</div>
									<div class="flex-fill">
										<ul clas="list-group">
											<li class="list-group-item bg-danger text-light">BORN<i class="fa fa-calender float-right"></i></li>
											<li class="list-group-item mb-4"><small>22 Jan, 2001 (18 years)</small></li>
											<li class="list-group-item bg-danger text-light">EDUCATION</li>
											<li class="list-group-item mb-4"><small>Assam University (B.Sc)</small></li>
											<li class="list-group-item bg-danger text-light">PROFILE</li>
											<li class="list-group-item mb-4">
												<i class="fa fa-facebook"></i>
												<i class="fa fa-twitter"></i>
												<i class="fa fa-google"></i>
											</li>
											<li class="list-group-item bg-danger text-light">CONTACT</li>
											<li class="list-group-item mb-4"><small>+91-9401346423, +91-9435764976</small></li>
										</ul>
									</div> -->
							</div>
						</div>
						<div id="mission" class="tab-pane">
							<h1>welcome to mission</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container-fluid p-0">
			<div class="jumbotron mb-0 m-0 bg-light rounded-0" id="people">
				<div class="row">
					<div class="col-md-6 pl-2 pl-lg-5 wow" id="what">
					<h2 class="mb-4 mb-lg-5" id="what-p">WHAT PEOPLE SAYS</h2>
						<div class="d-flex shadow-lg">
							<div class="flex-fill" style="background-color:white;">			
								<div class="carousel slide" data-ride="carousel" id="client-slider">
									<div class="carousel-inner">
										<div class="carousel-item active px-4 py-3">
											<div class="media">
												<img src="images/logo.png" width="80" height="80" class="shadow-sm rounded-circle" alt="f" />
												<div class="media-content p-3">
													<h5>Subrata Sinha</h5>
													<span>Student</span>
												</div>
											</div>
											<span class="d-block mt-3" style="line-height:30px;color:#999; text-align:justify;">
												typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only, printer took a galley of type and scrambled it to make a type specimen book. It has survived not only
											</span>
										</div>
										<div class="carousel-item px-4 py-3">
											<div class="media">
												<img src="images/logo.png" width="80" height="80" class="shadow-sm rounded-circle" alt="f" />
												<div class="media-content p-3">
													<h5>Subrata Sinha</h5>
													<span>Student</span>
												</div>
											</div>
											<span class="d-block mt-3" style="line-height:30px;color:#999; text-align:justify;">
												typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only, printer took a galley of type and scrambled it to make a type specimen book. It has survived not only
											</span>
										</div>
										<div class="carousel-item px-4 py-3">
											<div class="media">
												<img src="images/logo.png" width="80" height="80" class="shadow-sm rounded-circle" alt="f" />
												<div class="media-content p-3">
													<h5>Subrata Sinha</h5>
													<span>Student</span>
												</div>
											</div>
											<span class="d-block mt-3" style="line-height:30px;color:#999; text-align:justify;">
												typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only, printer took a galley of type and scrambled it to make a type specimen book. It has survived not only
											</span>
										</div>
										<div class="carousel-item px-4 py-3">
											<div class="media">
												<img src="images/logo.png" width="80" height="80" class="shadow-sm rounded-circle" alt="f" />
												<div class="media-content p-3">
													<h5>Subrata Sinha</h5>
													<span>Student</span>
												</div>
											</div>
											<span class="d-block mt-3" style="line-height:30px;color:#999; text-align:justify;">
												typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only, printer took a galley of type and scrambled it to make a type specimen book. It has survived not only
											</span>
										</div>
									</div>
								</div>
							</div>
							<div class="d-flex flex-column justify-content-between py-2 px-3" style="background-color:#ED1C94">
								<i class="fa fa-arrow-circle-right" style="font-size:35px;color:white;" id="next-client"></i>
								<i class="fa fa-arrow-circle-left" style="font-size:35px;color:white;" id="prev-client">
								</i>
							</div>
						</div>
					</div>
					<div class="col-md-6 mt-5 text-white d-flex text-center flex-column justify-content-around">
						<div class="d-flex justify-content-around">
							<div>
								<i class="fa fa-users" style="color:yellow;font-size:35px;"></i>
								<h4 class="mt-3 mb-2" id="num-one"><?php 
									$count_query = "SELECT count(id) AS result FROM users";
									if($response = $db->query($count_query))
									{
										$data = $response->fetch_assoc();
									
											echo $data['result']."+";
									}
								?></h4>
								<p>Users</p>
							</div>
							<div>
								<i class="fa fa-plus-square-o" style="color:yellow;font-size:35px;"></i>
								<h4 class="mt-3 mb-2" id="num-two"><?php 
									$select_clinic= "SELECT locality FROM doctors";
									if($response = $db->query($select_clinic))
									{
										if($response->num_rows != 0)
										{
											while($data = $response->fetch_assoc())
											{
												$region[] = $data['locality'];
											}
											$uni = array_unique($region);
											$total_clinic =  count($uni);
											echo $total_clinic."+";
										}
										else
										{
											echo "not";
										}
										
										
									}
								?></h4>
								<p>Clinics</p>
							</div>
						</div>
						<div class="d-flex justify-content-around">
							<div>
								<i class="fa fa-user-plus" style="color:yellow;font-size:35px;"></i>
								<h4 class="mt-3 mb-2" id="num-three">5+</h4>
								<p>Labs</p>
							</div>
							<div>
								<i class="fa fa-user" style="color:yellow;font-size:35px;"></i>
								<h4 class="mt-3 mb-2" id="num-four"><?php 
									$count_query = "SELECT count(id) AS result FROM doctors";
									if($response = $db->query($count_query))
									{
										$data = $response->fetch_assoc();
									
										echo $data['result']."+";
									}
									
								?></h4>
								<p>Doctors</p>
							</div>
						</div>
					</div>
				</div>
			</div>
				
			
		</div>
			<!--Start Footer-->
			<?php require_once("assest/html/footer.php") ?>
			
			<!--End Footer-->

	</div>

</body>
</html>
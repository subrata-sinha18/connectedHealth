// JavaScript Document

// dynamic navbar toggler
$(document).ready(function(){
	$("#nav-icon").click(function(){
		$("#mobile-menu").collapse('toggle');
		$("#mobile-menu").addClass("animated zoomIn");
	});
});

// $(document).ready(function(){
// 	let string = "APPOINTMENT";
// 	let i=0;
// 	if(i<string.length)
// 		{
// 			setInterval(function(){
// 				document.querySelector(".add-head").innerHTML += string.charAt(i);
// 				i++;
// 			},200);
			
// 		}
// });


$(document).ready(function(){
	$("#search-icon").click(function(){
		$("#serach-input-box").collapse('toggle');
	});
	
	$("#serach-input-box").on('show.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"50px"});
	});
	
	$("#serach-input-box").on('hide.bs.collapse',function(){
		$("#header-slider h1").animate({marginTop:"0"});
	});
});

$(document).ready(function(){
	$("#next-client").click(function(){
		$("#client-slider").carousel('next');
	});
	$("#prev-client").click(function(){
		$("#client-slider").carousel('prev');
	});
});

$(window).scroll(function(){
	if(sessionStorage.getItem('user_scroll') == null)
		{
			let name = $("#what").attr("class");
			if(name.indexOf("animated") != -1)
				{
					animation();
					sessionStorage.setItem('user_scroll','yes');
				}
		}
	
	
});
function animation(){
	$(document).ready(function(){
	let num = 0;
	$.ajax({
		type : "POST",
		url : "php/count_users.php",
		success : response =>{
			total = response;
			let clear = setInterval(function(){
				num += 1;
				$("#num-one").html(num+"+");
				if(num == total)
					{
						clearInterval(clear);
					}
			},500);
		}
	});
	
});

$(document).ready(function(){
	let num = 0;
	$.ajax({
		type : "POST",
		url : "php/count_clinic.php",
		success : response =>{
			let total_clinic = response;
			let clear = setInterval(function(){
				num += 1;
				$("#num-two").html(num+"+");
				if(num == total_clinic)
					{
						clearInterval(clear);
					}
			},500);
		}
	});
	
});

$(document).ready(function(){
	let num = 0;
	let clear = setInterval(function(){
		num += 1;
		$("#num-three").html(num+"+");
		if(num == 5)
			{
				clearInterval(clear);
			}
	},500);
});

	$(document).ready(function(){
		let num = 0;
		$.ajax({
			type : "POST",
			url : "php/count_doctor.php",
			success : response =>{
				let total_doctors = response;
				let clear = setInterval(function(){
					num += 1;
					$("#num-four").html(num+"+");
					if(num == response)
						{
							clearInterval(clear);
						}
				},500);
			}
		});
	});
}
function login(){
	$(document).ready(function(){
		$(".login").each(function(){
			$(this).on("click",function(){
				window.location = "login/login.php";
			})
		});
	});
}
login();
$(document).ready(function(){
	$(".signup").each(function(){
		$(this).on("click",function(){
			window.location = "signup/signup.php";
		})
	});
});



$(document).ready(function(){
	$(".location").on("keyup",function(){
		if(this.value.length >2)
		{
			let val = this.value;
			$.ajax({
				type : "POST",
				url : "php/select_location.php",
				data : {
					value : val
				},
				beforeSend : () =>{

				},
				success : response =>{
					if(response.trim() != "not")
					{
						var json_response = JSON.parse(response);
						if(json_response.length>0)
						{
							$(".locationList").html("");
							$(".locationList").parent().removeClass("d-none");
							for(i=0;i<json_response.length;i++)
							{
								var json_response = JSON.parse(response);
								var li = document.createElement("LI");
								li.className = "list-group-item py-1 doctor_name";
								li.innerHTML = json_response[i];
								$(".locationList").append(li);
								
							}
							
						}
						else
						{
							$(".locationList").parent().addClass("d-none");
						}
						$(".locationList li").each(function(){
							$(this).click(function(){
								$(".location").val($(this).html());
								$(".locationList").parent().addClass("d-none");
								$.ajax({
									type : "POST",
									url : "php/select_specialization.php",
									data : {
										locality : $(this).html()
									},
									beforeSend : () =>{

									},
									success : response =>{
										var json_response = JSON.parse(response);
										var special_obj = Object.values(json_response);
										var i;
										var option = $("#specialization option");
										for(i=1;i<+ option.length;i++)
											{
												option[i].remove();
											}
										for(i=0;i<special_obj.length;i++)
										{
											var option = document.createElement("OPTION");
											option.innerHTML = special_obj[i];
											option.className = "dropdown-item";
											$("#specialization").append(option);
										}
										$(".search_btn").click(function(e){
											e.preventDefault();
											if($("#specialization").val() != "Select Specialization")
												{
													var region = $("#select_region").val();
													var specialization = $("#specialization").val();
													$.ajax({
														catch : false,
														type : "POST",
														url : "php/search_doctor.php",
														data : {
															region : btoa(region),
															specialization : btoa(specialization)
														},
														beforeSend : function(){
															$(".search_btn").html("Please Wait ...");
															$(".search_btn").attr("disabled","disabled");
														},
														success : function(response){
															var json_response = JSON.parse(response);
															var i;
															$(".doctorContainer").removeClass("d-none");
															$(".doctors").html("");
															$(".search_btn").html("Search");
															$(".search_btn").removeAttr("disabled");
															if(response.trim() == "No doctor found")
																{
																	var head = document.createElement("H4");
																	head.innerHTML = "No Doctor found";
																}
															if(json_response.length > 0)
																{
																	for(i=0;i<json_response.length;i++)
																	{
																		var parent_div = document.createElement("DIV");
																		parent_div.className = "doctor_item mb-5 p-3 d-flex flex-column align-items-center";
																		var img = document.createElement("IMG");
																		img.src = "images/doctor_logo.png";
																		img.style.width = "50px";
																		img.style.height = "50px";
																		var heading = document.createElement("H5");
																		heading.className = "py-1 text-primary";
																		heading.innerHTML = json_response[i][0];
																		var para_1 = document.createElement("P");
																		para_1.className = "p-0 m-0";
																		para_1.innerHTML = json_response[i][3];
																		var para_2 = document.createElement("P");
																		para_2.className = "p-0 m-0 mb-2";
																		para_2.innerHTML = json_response[i][2];
																		var btn = document.createElement("BUTTON");
																		btn.className = "btn text-center login";
																		btn.setAttribute("data-email",json_response[i][1]);
																		var icon = document.createElement("I");
																		icon.className = "fa fa-hand-o-right";
																		icon.style.fontSize = "25px";
																		btn.append(icon);
																		btn.innerHTML += " Check Availability";
																		parent_div.append(img);
																		parent_div.append(heading);
																		parent_div.append(para_1);
																		parent_div.append(para_2);
																		parent_div.append(btn);
																		$(".doctors").append(parent_div);
																	}
																	login();
																}
															$(".check_btn").each(function(){
																$(this).click(function(){
																	var doctor_email = $(this).attr("data-email");
																	window.location = "doctor_user_profile/doctor_user_profile.php?doctor_email="+doctor_email;
																});
															});
														},
													});
														
												}
											else
												{
													alert("Please Select an Specialization option");
												}
										});
									}
								});
							});
						})
					}
					// else
					// {
					// 	alert("Not found");
					// }
					
					

				}
			});
		}
	});
});

































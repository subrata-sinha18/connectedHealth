<?php
echo '
    <div class="footer">
				<div class="jumbotron rounded-0 mb-0 text-white">
					<div class="row">
						<div class="col-md-5 footer_menu">
							<a href="#" class="navbar-brand d-flex align-items-center p-0 m-0 pb-3">
								<img src="images/logo.png" alt="logo" class="mr-1" style="width:40px;">
								<h4 class="p-0 m-0 text-light"> Connected <span style="color:#082a2b;font-weight:bold;background-color:#fff;padding:2px 5px;">Health</span></h4>
							</a>
							<hr class="bg-light p-0 m-0">
							<ul class="">
								<li><a href="javascript:void(0)"><i class="fa fa-search" style="font-size:24px"></i>Book an Appointment</a></li>
								<li><a href="javascript:void(0)"><i class="fa fa-clipboard" style="font-size:24px"></i>Consult a Doctor Online</a></li>
								<li><a href="javascript:void(0)"><i class="fa fa-book" style="font-size:24px"></i>Read health articles</a></li>
								<li><a href="javascript:void(0)"><i class="fa fa-medkit" style="font-size:24px"></i>View medical records</a></li>
								<!-- <li><a href="#"><i class="fa fa-phone" style="font-size:24px"></i>Contact Us</a></li> -->
							</ul>
							
							
						</div>
						<div class="col-md-3 footer_middle">
						
							<ul class="my-5">
								<li><a href="javascript:void(0)">About us</a></li>
								<li><a href="javascript:void(0)">Contcat us</a></li>
								<li><a href="javascript:void(0)">Terms and service</a></li>
							</ul>
							<div class="social-box d-flex justify-content-around">
								<a href="javascript:void(0)"><i class="fa fa-facebook social_icon facebook_icon" style="font-size:18px;"></i></a>
								<a href="javascript:void(0)"><i class="fa fa-twitter social_icon twitter_icon" style="font-size:18px;"></i></a>
								<a href="javascript:void(0)"><i class="fa fa-instagram social_icon instagram_icon" style="font-size:18px;"></i></a>
								<a href="javascript:void(0)"><i class="fa fa-youtube social_icon youtube_icon" style="font-size:18px;"></i></a>
								<a href="javascript:void(0)"><i class="fa fa-linkedin social_icon linkedin_icon" style="font-size:18px;"></i></a>
							</div>
							
						</div>
						<div class="col-md-4">
							<img src="images/undraw_fill_in_mie5.svg" width="100%" alt="">
							
						</div>
					</div>
				</div>
            </div>
            ';

?>
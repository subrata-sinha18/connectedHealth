<?php
echo '
<nav class="navbar navbar-expand-md my-bg sticky-top top-nav" style="height:10vh;background-color:#fff;">
<i class="fa fa-bars navbar-toggler" style="font-size:35px;color:white;" id="nav-icon"></i>
<a href="#" class="navbar-brand d-flex align-items-center">
    <img src="images/logo.png" alt="logo" class="mr-1" style="width:40px;">
    <h4 class="p-0 m-0 text-dark"> Connected <span style="color:#082a2b;font-weight:bold">Health</span></h4>
</a>
<div class="collapse navbar-collapse" id="mobile-menu">
    <ul class="navbar-nav ml-auto">
        <li class="nav-item mr-5">
            <button class="login backToHomeBtn"><i class="fa fa-home text-light mr-2"></i>Home</button>
        </li>
        <li class="nav-item mr-5">
            <a href="php/logout.php"><button class="signup signOutBtn">Sign out</button></a>
        </li>
    </ul>
</div>
</nav>';

?>
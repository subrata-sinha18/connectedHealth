<?php
echo '
    body::-webkit-scrollbar {
	width: 10px;
  }
body::-webkit-scrollbar-track {
	background: #f1f1f1;
  }
body::-webkit-scrollbar-thumb {
	background: #888;
  }
body::-webkit-scrollbar-thumb:hover {
	background: #555;
  }
.footer_menu ul,.footer_middle ul
{
	list-style:none;
	width:100%;
	padding:0;
	margin:0;
	padding:20px 0px;
}
.footer_menu ul li
{
	padding:12px 10px;
	width:100%;
	
}

.footer_middle ul li
{
	padding:5px 10px;
}
.footer_menu ul li a
{
	text-decoration: none;
	color:#fff;
}
.footer_middle ul li a
{
	text-decoration: none;
}
.footer_middle a:hover{
	text-decoration: none;
}

.footer_menu ul li a i
{
	margin-right:30px;
}
.social_icon
{
	color:#fff;
	width:40px;
	height:40px;
	border:1px solid #ccc;
	display: flex;
	justify-content: center;
	align-items: center;
	border-radius: 50%;
}
.facebook_icon:hover{
	background-color: #3D64A4;
	border:none;
}
/* .social-box
{
	width:50%;
	display:flex;
	justify-content: space-evenly;
} */

.twitter_icon:hover{
	background-color: #00A9E8;
	border:none;
}
.instagram_icon:hover{
	background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%,#d6249f 60%,#285AEB 90%);
	border:none;
}
.youtube_icon:hover{
	background-color: #F80000;
	border:none;
}
.linkedin_icon:hover{
	background-color: #0078B0;
	border:none;
}

.footer{
	background-image:url("images/footer-background.png");
	background-size:10% auto;
}
.footer>.jumbotron
{
	background-color:rgba(0,0,0,0.9);
	padding:40px 10%;
}

';


?>
<?php
echo '
.navbar a
{
	color:white;
}
nav{
	box-shadow:1px 3px 2px rgba(0,0,0,0.6);
}
.text-white
{
	color:white;
}

nav .login, nav .signup{
	background-color:inherit;
	border:none;
	color:#fff;
	padding:7px 14px;
	box-shadow:2px 1px 4px rgba(0,0,0,0.6);
	border-radius:5px;
	background-color:#337b99;
}
';


?>
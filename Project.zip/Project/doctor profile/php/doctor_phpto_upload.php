<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$get_id_response = $db->query($get_id);
$data = $get_id_response->fetch_assoc();
$folder_name = "../gallery/doctor_".$data['id']."/";
$file = $_FILES['data'];
$file_path = $file['tmp_name'];
$file_size = round($file['size']/1024/1024,2);
$file_name = $file['name'];
$complete_path = $folder_name.$file_name;
//$table_name = "doctor_".$data['id'];
if(move_uploaded_file($file_path,$folder_name.$file_name))
{
//	$store_image = "INSERT INTO doctors(image_name,image_path,image_size)VALUES('$file_name','$complete_path','$file_size') WHERE email = '$email'";
	$update_image = "UPDATE doctors SET image_name = '$file_name', image_path = '$complete_path', image_size = '$file_size' WHERE email = '$email'";
	if($db->query($update_image))
	   {
		   echo "success";
		
	   }
	   else
	   {
		   echo "Fail to store image";
	   }
	
	
}
else
{
	echo "failed";
}











?>
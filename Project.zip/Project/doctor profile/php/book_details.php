<?php
require("../../php/database.php");
$table_name = $_POST['table'];
$select = "SELECT * FROM $table_name";
$response = $db->query($select);
while($data = $response->fetch_assoc())
{
	$id = $data['id'];
	$name = $data['name'];
	$date = $data['date'];
	$age = $data['age'];
	$gender = $data['gender'];
	$phone = $data['phone'];
	$date_of_book = $data['book_date'];
	$patient_details[] = [$id,$name,$date,$age,$gender,$phone,$date_of_book];
}
echo json_encode($patient_details);

?>
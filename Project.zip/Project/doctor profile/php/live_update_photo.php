<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$get_path = "SELECT image_path FROM doctors WHERE email ='$email'";
$response = $db->query($get_path);
$path = $response->fetch_assoc();
$image_path = $path['image_path'];
$actual_image_path = str_replace("../","",$image_path);
echo "<img src='$actual_image_path' alt='$actual_image_path' style='width:100%;height:100%;' />";
?>
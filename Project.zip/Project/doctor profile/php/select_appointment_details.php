<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$id_response = $db->query($get_id);
$id_data = $id_response->fetch_assoc();
$id = $id_data['id'];
$partial_table = "doctor_".$id."%";
$get_tables = "SHOW TABLES FROM doctorbooking LIKE '$partial_table'";
$response = $db->query($get_tables);
while($data = $response->fetch_assoc())
{
	$table[] = $data;
	
}

echo json_encode($table);
//$length_of_table = sizeof($table);
////echo $length_of_table;
//$i;
//for($i=0;$i<$length_of_table;$i++)
//{
//	$table_bame = $table[$i];
//	$get = "SELECT date FROM $table_bame id = 1";
//	$resonse = $db->query($get);
//	$data = $resonse->fetch_assoc();
////	$count = $data['count'];
//	$date = $data['date'];
//	$table_detaild[] = $date;
//}
//echo json_encode($table_detaild);
////echo json_encode($table);

?>
<?php
require("../../php/database.php");
$patientId = $_POST['id'];
$thisDay = $_POST['thisDay'];
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$id_response = $db->query($get_id);
$id_data = $id_response->fetch_assoc();
$doctorId = $id_data['id'];
$tableName = "doctor_".$doctorId."_".$thisDay;
$update = "UPDATE $tableName SET check_status = 'not checked',checked_time='' WHERE id= '$patientId'";
if($db->query($update))
{
    //echo "updated";
    $select_count = "SELECT total_count,user FROM $tableName WHERE id = '$patientId'";
    if($response_count = $db->query($select_count))
    {
        $data_count = $response_count->fetch_assoc();
        $count_data = $data_count['total_count'];
        $user_id = $data_count['user'];
        $user_table = "user_".$user_id;
        $update_user = "UPDATE $user_table SET check_status = 'not checked', checked_at = '' WHERE total_booked = '$count_data'";
        if($db->query($update_user))
        {
            echo "updated";
        }
        else
        {
            echo "not updated 1";
        }
    }
}
else
{
    echo "not updated";
}

?>
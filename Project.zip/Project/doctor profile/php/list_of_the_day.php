<?php
require_once("../../php/database.php");
$thisDay = $_POST['thisDay'];
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$id_response = $db->query($get_id);
$id_data = $id_response->fetch_assoc();
$id = $id_data['id'];
$tableName = "doctor_".$id."_".$thisDay;
$select = "SELECT * FROM $tableName";
$select_list = [];
if($response = $db->query($select))
{
    while($data = $response->fetch_assoc())
    {
        array_push($select_list,$data);
    }
    echo json_encode($select_list);
}
else
{
    echo "not found";
}

?>
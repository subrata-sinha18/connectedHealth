<?php
require("../../php/database.php");
$patientId = $_POST['id'];
$thisDay = $_POST['thisDay'];
$text = $_POST['text'];
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$id_response = $db->query($get_id);
$id_data = $id_response->fetch_assoc();
$doctorId = $id_data['id'];
$tableName = "doctor_".$doctorId."_".$thisDay;
$update = "UPDATE $tableName SET notes = '$text' WHERE id= '$patientId'";
if($db->query($update))
{
    echo "updated";
}
else
{
    echo "not updated";
}

?>
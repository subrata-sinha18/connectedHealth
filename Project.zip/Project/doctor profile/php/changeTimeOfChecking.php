<?php
require("../../php/database.php");
$day = $_POST['date'];
$time = $_POST['time'];
session_start();
$email = $_SESSION['email'];
$get_id = "SELECT id FROM doctors WHERE email = '$email'";
$id_response = $db->query($get_id);
$id_data = $id_response->fetch_assoc();
$id = $id_data['id'];
$tableName = "doctor_".$id."_".$day;
$duration = $_POST['duration'];
$duration_parts = explode(":",$duration);
$duration_in_minute = (60*$duration_parts[0])+$duration_parts[1];
$newUpdatedTime = [];
$count = "SELECT COUNT(id) AS count_result FROM $tableName";
if($count_response = $db->query($count))
{
    $count_data = $count_response->fetch_assoc();
    $totalPatients = $count_data['count_result'];
    for($i = 0;$i<$totalPatients;$i++)
    {
        $id_no = $i+1;
        $patient_duration = $duration_in_minute*$i;
        $bookdate_parts = explode("_",$day);
		$bookDate = $bookdate_parts[2]."-".$bookdate_parts[1]."-".$bookdate_parts[0];
		$request_date = $bookDate." ".$time;
        $request_time = strval($request_date);
        $patient_duration_time = strval($patient_duration);
        $dateTime = DateTime::createFromFormat( 'Y-m-d H:i', $request_date );
        $dateTime->add( new DateInterval( 'PT' . ( (integer) $patient_duration_time ) . 'M' ) );
        $newTime = $dateTime->format( 'H:i' );
        $update_query = "UPDATE $tableName SET checked_at = '$newTime'  WHERE id ='$id_no'";

        if($db->query($update_query))
        {
            $selectQuery = "SELECT user,total_count FROM $tableName WHERE id='$id_no'";
            if($select_response = $db->query($selectQuery))
            {
                $select_data = $select_response->fetch_assoc();
                $user_id = $select_data['user'];
                $total_booked = $select_data['total_count'];
                $user_table = "user_".$user_id;
                $user_update = "UPDATE $user_table SET checked_time='$newTime' WHERE total_booked='$total_booked'";
                if($db->query($user_update))
                {
                    $get_email = "SELECT email,patient_name,doctor_name FROM $user_table WHERE  total_booked='$total_booked'";
                    if($email_response = $db->query($get_email))
                    {
                        $email_data = $email_response->fetch_assoc();
                        $user_email = $email_data['email'];
                        $name = $email_data['patient_name'];
                        $doctor_name = $email_data['doctor_name'];
                        if(mail($email,"Change in time","Hey ".$name.", Your treatment is rescheduled at".$newTime." for doctor ".$doctor_name))
                        {
                            $newTime_str = strval($newTime);
                            array_push($newUpdatedTime,$newTime_str);
                        }
                        else
                        {
                            echo "error";
                        }
                    }
                    
                    
                }
                else
                {
                    echo "error";
                }
            }
        }
        else
        {
            echo "error";
        }

    }
    echo json_encode($newUpdatedTime);
}
else
{
    echo "error";
}

?>
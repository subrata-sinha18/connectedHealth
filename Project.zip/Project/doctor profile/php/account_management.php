<?php
require("../../php/database.php");
session_start();
$email = $_SESSION['email'];
$clinic_name = base64_decode($_POST['clinic_name']);
$clinic_address = base64_decode($_POST['clinic_address']);
$days = base64_decode($_POST['days']);
$seat_number = base64_decode($_POST['seat_number']);
$starting_time = base64_decode($_POST['starting_time']);
$duration = base64_decode($_POST['duration']);
$amount = base64_decode($_POST['amount']);
$update_details = "UPDATE doctors SET clinic_name = '$clinic_name', clinic_address='$clinic_address', visit_on='$days', start_time = '$starting_time',duration = '$duration',total_seat='$seat_number', charge_per_patient='$amount' WHERE email = '$email'";
if($db->real_query($update_details))
{
	//echo "success";
	// $select_details = "SELECT clinic_name,clinic_address,visit_on,start_time,total_seat,charge_per_patient FROM doctors WHERE email = '$email'";
	// $select_response = $db->query($select_details);
	// $select_data = $select_response->fetch_assoc();
	// $new_clinic_name = $select_data['clinic_name'];
	// $new_clinic_address = $select_data['clinic_address'];
	// $new_visit_on = $select_data['visit_on'];
	// $start_time = $select_data['start_time'];
	// $new_total_seat = $select_data['total_seat'];
	// $new_charge_per_patient = $select_data['charge_per_patient'];
	// $response = [$new_clinic_name,$new_clinic_address,$new_visit_on,$new_total_seat,$new_charge_per_patient];
	// echo json_encode($response);
	$select_details = "SELECT * FROM doctors WHERE email = '$email'";
	
	if($select_response = $db->query($select_details))
	{
		$select_all = [];
		$data = $select_response->fetch_assoc();
		array_push($select_all,$data);
		echo json_encode($select_all);
		
	}
}
else
{
	echo "failed";
}

?>

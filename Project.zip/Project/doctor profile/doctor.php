<?php
session_start();
if(empty($_SESSION['email']))
{
	echo "not found";
	header("Location:../index.html");
	exit;
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title><?php
	require("../php/database.php");
	$email = $_SESSION['email'];
	$get_name = "SELECT name,contact_number,locality,clinic_name,clinic_address,visit_on,start_time,duration,total_seat,charge_per_patient,image_path FROM doctors WHERE email = '$email'";
	$name_response = $db->query($get_name);
	$data = $name_response->fetch_assoc();
	$final_name = $data['name'];
	$locality = $data['locality'];
	$clinic_name = $data['clinic_name'];
	$clinic_address = $data['clinic_address'];
	$visit_on = $data['visit_on'];
	$start_time = $data['start_time'];
	$time_parts = explode(":",$start_time);
	$final_time = $time_parts[0].":".$time_parts[1];
	$duration_start_time = $data['duration'];
	$duration_time_parts = explode(":",$duration_start_time);
	$duration_final_time = $duration_time_parts[0].":".$duration_time_parts[1];
	$total_seat = $data['total_seat'];
	$charge_per_patient = $data['charge_per_patient'];
	$contact_number = $data['contact_number'];
	$image_path = $data['image_path'];
	$actual_image_path = str_replace("../","",$image_path);
	echo $final_name;
	?></title>
	<link rel="icon" href="<?php echo $actual_image_path ?>" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/multipicker.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Righteous&display=swap|PT+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Gudea">
	<link rel="stylesheet" href="DataTables/datatables.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/multipicker.min.js"></script>
	<script src="js/account_management_ajax.js"></script>
	<script src="js/change_password.js"></script>
	<script src="DataTables/datatables.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript">
	
		$(function() {
			$("#days").multiPicker({ selector : "li" });

			$("#languages").multiPicker({
				selector	: "radio"
			});

			$("#programming-languages").multiPicker({
				selector	: "checkbox",
				cssOptions : {
					size 	  : "large"
				}
			});
		});
	</script>
	<style>
		<?php require_once("../assest/css/header.php"); ?>
		<?php require_once("../assest/css/footer.php"); ?>
	</style>
</head>
<body>
	<div>
		<?php require_once("../assest/html/header.php"); ?>
		<div class="main-con d-flex">
			<div class="nav-box py-4 px-3">
				<div>
					<h5 class="text-white mb-3">User's Area</h5>
					<ul id="myTab" role="tablist">
						<li class="profile_link"><a href="#"><i class="fa fa-fw fa-user-md" style="font-size:24px"></i>My Profile</a></li>
						<li class="accontManagementLink"><a href="#"><i class="fa fa-fw fa-user" style="font-size:24px"></i>Manage Account</a></li>
						<li class="wallet_link"><a href="#"><i class="fa fa-fw fa-inr" style="font-size:24px"></i>My Wallet</a></li>
						<li class="bookAppointment"><a href="#"><i class="fa fa-fw fa-book" style="font-size:24px"></i>Book Appointment</a></li>
						<li class="todayConLink"><a href="#"><i class="fa fa-fw fa-file" style="font-size:24px"></i>Patients list</a></li>
						<li  class="change_password_link"><a href="#"><i class="fa fa-fw fa-user" style="font-size:24px"></i>Change Password</a></li>
						<li><a href="php/logout.php" style="display:block;width:100%;height:100%"><i class="fa fa-fw fa-lock" style="font-size:24px"></i>Sign Out</a></li>
					</ul>
				</div>
			</div>
			<div class="main-section-box">
				<div class="header-name-box p-3 d-flex">
					<div class="w-50">
						<span class="text-white mb-1">WELCOME</span>
						<h3 class="text-white">
							<?php
								echo $final_name;
							?>
						</h3>
					</div>
					<div class="w-50 d-flex justify-content-end align-items-end">
						<p class="p-0 m-0 text-white">Login As : &nbsp;&nbsp;<span>Doctor</span></p>
					</div>
					
					
				</div>
				<div class="main-section">
					<div class="profile">
						<div class="profile_box d-flex justify-content-between px-4 pt-4">
							<div class="profile_pic_box">
								<?php
									echo "<img src='$actual_image_path' alt='$actual_image_path' style='width:100%;height:100%;' />";
								
								?>
							</div>
							<div class="p-3">
								<p class="p-0 m-0">Login As : &nbsp;&nbsp;<span>Doctor</span></p>
							</div>
							
						</div>
						<div class="appear">
							<div class="profile_con p-4 userContainer">
								<div class="card">
									<div class="card-header bg text-white">
										<h4>User's Details</h4>
									</div>
									<div class="card-body">
										<ul class="list-group details-ul">
											<li class="list-group-item py-3"><span>Name : </span><span><?php echo $final_name; ?></span></li>
											<li class="list-group-item py-3"><span>Email Id : </span><span><?php echo $email; ?></span></li>
											<li class="list-group-item py-3"><span>Contact Number : </span><span><?php echo $contact_number; ?></span></li>
											<li class="list-group-item py-3"><span>Locality : </span><span><?php echo $locality; ?></span></li>
										  </ul>
									</div>
<!--
									<div class="card-footer bg-danger text-white">
										<button class="btn btn-warning edit_profile text-white float-right">Edit</button>
									</div>
-->
								</div>
							</div>
							
<!--							--------------------------------------------------------------->
							<div class="manage_con p-4" style="display: none">
							
							<div class="card">
								<form>
									<div class="card-header bg text-white">
										<h4>Account Management</h4>
									</div>
									<div class="card-body bg-dark">
										<div class="form-group">
											<label for="clinic_name" class="text-white">Clinic Name</label>
											<input type="text" class="form-control" id="clinic_name" value="<?php echo $clinic_name; ?>" />
										</div>
										<div class="form-group">
											<label for="clinic_address" class="text-white">Clinic Address</label>
											<textarea name="clinic_address" id="clinic_address" class="form-control"><?php echo $clinic_address; ?></textarea>
										</div>
										
										<div class="form-group">
											<label for="visit" class="text-white mr-5">Visit on</label>
											<ul id="days" class="bg-light">
												<li>Su</li>
												<li>Mo</li>
												<li>Tu</li>
												<li>We</li>
												<li>Th</li>
												<li>Fr</li>
												<li>Sa</li>
											</ul>
										  </div>
										<div class="form-group d-none">
											<label for="visit" class="text-white mr-5">Previous Selected</label>
											<p class="text-warning" id="days_list"><?php echo $visit_on; ?></p>
										</div>
										  <div class="form-group">
											<label for="seat_number" class="text-white">Total Number of Seats</label>
											<input type="number" class="form-control" value="<?php echo $total_seat; ?>" id="seat_number" />
										</div>
										<div class="form-group">
											<label for="starting_time" class="text-white">Starting Time of Checking</label>
											<input type="time" class="form-control" id="starting_time" value="<?php echo $final_time ?>" />
										</div>
										<div class="form-group">
											<label for="starting_time" class="text-white">Average Duration</label>
											<input type="time" class="form-control" id="duration" value="<?php echo $duration_final_time ?>"  />
										</div>
										<div class="form-group">
											<label for="amount" class="text-white">Charge per patient</label>
											<input type="number" class="form-control" value="<?php echo $charge_per_patient; ?>" id="amount" placeholder="&#x20B9 200.00" />
										</div>
										
										<button class="btn btn-primary text-light management_btn">Submit</button>
										<div class="success_message mt-3">
											
										</div>
									</div>
								</form>
							</div>

						</div>
							<div class="appointment_con p-4" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>Appointment Details</h4>
								</div>
								<div class="card-body table-responsive-sm">
									<table class="table table-dark table-hover" id="myTable">
										<thead>
										  <tr>
											<th class="text-center" style="width:15%">Sl No.</th>
											<th class="text-center" style="width:35%">Date</th>
											<th class="text-center" style="width:50%">View Details</th>
										  </tr>
										</thead>
										<tbody class="tbody">
										  
										</tbody>
									  </table>
									<table class="table table-dark table-details" style="display:none" id="detailsTable">
										<thead>
										  <tr>
											  <th class="text-center bg-dark text-light">Sl No.</th>
											  <th class="text-center bg-dark text-light">Name</th>
											  <th class="text-center bg-dark text-light">Date</th>
											  <th class="text-center bg-dark text-light">Age</th>
											  <th class="text-center bg-dark text-light">Gender</th>
											  <th class="text-center bg-dark text-light">Phone</th>
											  <th class="text-center bg-dark text-light">Booked on</th>
										  </tr>
										</thead>
										<tbody class="tbody_details">
										  
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<div class="wallet_con p-4" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>User's Details</h4>
								</div>
								<div class="card-body">
									<h1>Wallet</h1>
								</div>
								<div class="card-footer bg-danger text-white">
									<button class="btn btn-warning edit_profile text-white float-right">Edit</button>
								</div>
							</div>
							

						</div>
						<div class="today_con p-4" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white d-flex justify-content-between">
									<h4>Patients list of the day</h4>
									<div class="form-group mb-0">
										<label for="starting_time_of_the_day mb-0" class="text-white">Starting Time</label>
										<input type="time" class="form-control" id="starting_time_of_the_day" value="<?php echo $final_time ?>"  />
									</div>
									<div class="form-group mb-0">
										<label for="duration_of_the_day mb-0" class="text-white">Duration</label>
										<input type="time" class="form-control" id="duration_of_the_day" value="<?php echo $duration_final_time ?>"  />
									</div>
									<div>
									<label for="listDate mb-0" class="text-white">Date</label>
										<input class="form-control" type="text" id="listDate">
									</div>
									<button class="btn btn-warning changeTimeBtn mt-auto">Confirm</button>
								</div>
								<div class="card-body thisDayListTableBody">
								<table class="table table-dark thisDayListTable">
										<thead>
										  <tr>
											  <th class="bg-dark text-light">Sl No.</th>
											  <th class="bg-dark text-light">Name</th>
											  <th class="bg-dark text-light">Age</th>
											  <th class="bg-dark text-light">Gender</th>
											  <th class="bg-dark text-light">Phone</th>
											  <th class="bg-dark text-light">Booked on</th>
											  <th class="bg-dark text-light">Notes</th>
											  <th class="bg-dark text-light">Check Status</th>
											  <th class="bg-dark text-light">Checked Time</th>
										  </tr>
										</thead>
										<tbody class="thisDayList">
										
										  
										</tbody>
										
									</table>
									
									
								</div>
								<div class="card-footer">
									<h3 class="text-center listMessage" style="display:none"></h3>
								</div>
								
							</div>
							

						</div>
						
						<div class="password_con p-4 userContainer user-pro" style="display: none">
							
							<div class="card">
								<div class="card-header bg text-white">
									<h4>Change Password</h4>
								</div>	
								<div class="card-body bg-dark px-5">
									<form autocomplete="off">
										<div class="form-group">
											<label for="old_password" class="text-white">Enter Old Password</label>
											<input type="password" class="form-control" id="old_password" />
										</div>
										<div class="form-group">
											<label for="new_password" class="text-white">Enter New Password</label>
											<input type="password" class="form-control" id="new_password" />
										</div>
										<div class="form-group">
											<label for="repeat_password" class="text-white">Repeat New Password</label>
											<input type="password" class="form-control" disabled="disabled" id="repeat_password" />
										</div>
										<button class="btn btn-success change_btn" disabled="disabled" type="submit" >Change Password</button>
									</form>
									<div class="changed_notice p-2">
				
									</div>
								</div>
							</div>
							

						</div>
						</div>
					</div>
					
					

				</div>

			</div>
		</div>


	<!-- ----------------------------------------------------------End main section-------------------------------------------------------------- -->
    
		<?php require_once("../assest/html/footer.php"); ?>
	</div>
	<script>
		$(document).ready(function(){
			let date  = new Date();
			let day = date.getDate();
			let month = date.getMonth()+1;
			let year = date.getFullYear();

			let final_date = day+"/"+month+"/"+year;
			$( "#listDate").val(final_date);
			$( "#listDate").datepicker({
				dateFormat: 'dd/mm/yy',
				
				
			});
		});
	</script>
    

	<!--	------------Modal-->
	<div class="modal" id="noteShow">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-body">
					<p class="noteShowBody p-5 text-justify">
						
					</p>
				
				</div>
			</div>
		</div>
	</div>
	
	
</body>
</html>











// JavaScript Document
//$(document).ready(function(){
//    $(".edit_profile").click(function(e){
//        e.preventDefault();
//        if($(this).html() == "Edit")
//        {
//            $(this).html("Save");
//            $(this).removeClass("btn-warning");
//            $(this).addClass("btn-primary");
//            $(".details-ul li span:nth-child(2)").attr("contenteditable","true");
//            $(".details-ul li span:nth-child(2)")[0].focus();
//            $(".details-ul li span:nth-child(2)").each(function(){
//                $(this).css("border","0.5px dashed rgb(0,0,255)");
//            })
//        }
//        else if($(this).html() == "Save")
//        {
//            $(".details-ul li span:nth-child(2)").attr("contenteditable","false");
//            $(".details-ul li span:nth-child(2)").each(function(){
//                $(this).css("border","none");
//            })
//            $(this).html("Edit");
//            alert("saved");
//            $(this).removeClass("btn-primary");
//            $(this).addClass("btn-warning");
//        }
//        
//    })
//});
// let activeOnLi = () =>
// {
// 	alert();
// 	let visit_on = document.getElementById("days_list").innerHTML;
// 	alert(visit_on);
// 	// for(let j=0;j<visit_on.length;j++)
// 	// {
// 	// 	$("#days li").each(function(){
// 	// 		let li = $(this);
// 	// 		if($(this).html() == visit_on[j])
// 	// 		{
// 	// 			li.addClass("active");
// 	// 		}
// 	// 	});
// 	// }
// }
// activeOnLi();
$(document).ready(function(){
	let days = $("#days_list").html();
	let visit_on = days.split(",");
	for(let j=0;j<visit_on.length;j++)
	{
		$("#days li").each(function(){
			let li = $(this);
			if($(this).html() == visit_on[j])
			{
				li.addClass("active");
			}
		});
	}
});


$(document).ready(function(){
	$(".profile_pic_box").click(function(){
		var input = document.createElement("INPUT");
		input.type = "file";
		input.accept = "image/*";
		input.click();
		input.onchange= function(){
			
			var file = new FormData();
			file.append("data",this.files[0]);
			$.ajax({
				type : "POST",
				url : "php/doctor_phpto_upload.php",
				data : file,
				contentType : false,
				processData : false,
				cache : false,
				success : function(response){
					$.ajax({
						type : "POST",
						url : "php/live_update_photo.php",
						success : function(response){
							$(".profile_pic_box").html(response);
						}
					});
				}
			});
		};
	});
});

$(document).ready(function(){
	$(".profile_link").click(function(){
		$(".manage_con, .appointment_con, .wallet_con,.password_con,.today_con").fadeOut(500,function(){
			$(".profile_con").fadeIn(500);
		});
	});
	$(".accontManagementLink").click(function(){
		$(".profile_con, .appointment_con, .wallet_con,.password_con,.today_con").fadeOut(500,function(){
			$(".manage_con").fadeIn(500);
		});
	});
	$(".wallet_link").click(function(){
		$(".profile_con, .appointment_con, .manage_con,.password_con,.today_con").fadeOut(500,function(){
			$(".wallet_con").fadeIn(500);
		});
	});
	$(".bookAppointment").click(function(){
		$(".profile_con, .wallet_con, .manage_con,.table-details,.password_con,.today_con").fadeOut(500,function(){
			$(".appointment_con").fadeIn(function(){
				$(".table-hover").parent().fadeIn(500,function(){
					var tbody = document.getElementsByClassName("tbody_details");
					tbody[0].innerHTML = "";
					
				})
			});
			
		});
	});
	$(".change_password_link").click(function(){
		$(".profile_con, .appointment_con, .manage_con,.wallet_link,.today_con").fadeOut(500,function(){
			$(".password_con").fadeIn(500);
		});
	});
	$(".todayConLink").click(function(){
		
		$(".thisDayListTableBody").addClass("d-none");
		onloadListOfTheDay();
		$(".profile_con, .appointment_con, .manage_con,.wallet_link").fadeOut(500,function(){
			$(".today_con").fadeIn(500);
			
			
		});
	});
	
});

let onloadListOfTheDay = () =>{
	let date = new Date();
	let day = date.getDate();
	let month = date.getMonth()+1;
	let year = date.getFullYear();
	let thisDay = day+"_"+month+"_"+year;
	listOfTheDay(thisDay);
}
let dateOnChangeDay = () =>{
	$(document).ready(function(){
		$("#listDate").on("change",function(){
			
			let val = this.value;
			let parts = val.split("/");
			let day = "";
			let month = "";
			if(parts[0].charAt(0) == "0")
			{
				day = parts[0].replace("0","");
			}
			else
			{
				day = parts[0];
			}
			if(parts[1].charAt(0) == "0")
			{
				month = parts[1].replace("0","");
			}
			else
			{
				month = parts[1];
			}
			
			let date = day+"_"+month+"_"+parts[2];
			listOfTheDay(date);
		});
	});
	
	
}
dateOnChangeDay();
let listOfTheDay = thisDay =>{
	$(".thisDayListTableBody").addClass("d-none");
	let date = new Date();
	var time = date.getHours() + ":" + date.getMinutes();
	$.ajax({
		type : "POST",
		url : "php/list_of_the_day.php",
		data : {
			thisDay : thisDay
		},
		beforeSend : () =>{
			$(".listMessage").css("display","block");
			$(".listMessage").html('<i class="fa fa-spinner fa-spin"></i>');
		},
		success : response =>{
			
			if(response.trim() != "not found")
			{
				$(".listMessage").css("display","none");
				$(".thisDayListTableBody").removeClass("d-none");
				$(".listMessage").html('');
				let json_response = JSON.parse(response);
				console.log(json_response);
				var i;
				$(".thisDayList").html("");
				for(i=0;i<json_response.length;i++)
				{
					let checked_status = json_response[i].check_status;
					let status = "";
					if(checked_status == "checked")
					{
						status = "checked";
					}
					else
					{
						status = "";
					}
					let notes_val = "";
					if(json_response[i].notes != null)
					{
						
						notes_val = json_response[i].notes;
					}
					else
					{
						notes_val = "";
					}
					
					let final_checked_time = "";
					let part_1 = "";
					let part_2 = "";
					if(json_response[i].checked_time != null)
					{
						if(json_response[i].checked_time.indexOf("00:00") == -1)
						{

							let checked_time_parts = json_response[i].checked_time.split(":");
							part_1 = checked_time_parts[0];
							part_2 = checked_time_parts[1];
							final_checked_time = checked_time_parts[0]+":"+checked_time_parts[1];
						}
						else
						{
							final_checked_time = "";
						}
						
					}
					else
					{
						final_checked_time = "";
					}
					
					let actual_checked_time =json_response[i].checked_at.split(":");
					let actual_time = actual_checked_time[0]+":"+actual_checked_time[1];
					let dooked_date = json_response[i].book_date.replace("-","/").replace("-","/").split(" ");
					let color = "";
					if(part_1>actual_checked_time[0])
					{
						color = "red";
					}
					else if(part_1==actual_checked_time[0])
					{
						if(part_2>actual_checked_time[1])
						{
							color = "red";
						}
						else
						{
							color="green";
						}
					}
					else
					{
						color = "green";
					}
					
					var tr = `<tr>
									<th class="bg-dark text-light id">`+(i+1)+`</th>
									<th class="bg-dark text-light">`+json_response[i].name+`</th>
									<th class="bg-dark text-light">`+json_response[i].age+`</th>
									<th class="bg-dark text-light">`+json_response[i].gender+`</th>
									<th class="bg-dark text-light">`+json_response[i].phone+`</th>
									<th class="bg-dark text-light">`+dooked_date[0]+`<br /><span class="text-warning" style="font-size:12px;">${dooked_date[1]}</span></th>
									
									<th class="bg-dark text-light">
										<div class="position-relative">
											
											<textarea class="custom-control p-1 w-100 patientNote" id="remarks" maxlength="250" rows="2">${notes_val}</textarea>
											<span class="parentSpan" style="background-color:black;position:absolute;top:0;right:0;font-size:12px;padding:0px 2px;display:none;"><span class="countNotes">0</span>/250</span>
											<button class="notesUpdateBtn" style="padding:2px 4px;background-color:blue;z-index:1;position:absolute;bottom:0;left:0;font-size:12px;color:white;border:none;outline:none;display:none;">Update</button>
										</div>
									</th>
									<th class="bg-dark text-light">
										<div class="custom-contron custom-switch mb-3">
										<input type="checkbox" name="accept" class="custom-control-input checkBtn" ${status} id="check_${i}" />
										<label for="check_${i}" class="custom-control-label float-left"></label>   
										</div>
									
									</th>
									<th class="bg-dark text-light checkedTime"><span class="postTime">`+actual_time+"</span> <pre class='displayTime p-0 m-0' style='color:"+color+"'>"+final_checked_time+`</pre></th>
							</tr>`;
					var tbody = document.querySelector(".thisDayList");
					tbody.innerHTML += tr;
				}
				$(".thisDayListTable").DataTable();
				$(".patientNote").each(function(){
					$(this).click(function(){
						$(".patientNote").each(function(){
							$(this).parent().children("button").fadeOut();
							$(this).parent().children(".parentSpan").fadeOut();
						});
					});
				});
				$(".patientNote").each(function(){
					$(this).dblclick(function(){
						
						$(".noteShowBody").html($(this).val());
						$("#noteShow").modal();
					});
				});

				$(".patientNote").each(function(){
					$(this).on("input",function(e){
						$(this).parent().children("button").fadeIn();
						$(this).parent().children(".parentSpan").fadeIn();
						let countText = this.value.length;
						let span= this.parentElement.querySelector(".countNotes");
						span.innerHTML = countText;
						// $(this).on("click",function(){
						// 	$(this).parent().children("button").fadeOut();
						// 	$(this).parent().children(".parentSpan").fadeOut();
						// });
						// if(e.keyCode == 68)
						// {
							
						// 	$(".noteShowBody").html($(this).val());
						// 	$("#noteShow").modal();
						// }
						
					});
				});
				$(".notesUpdateBtn").each(function(){
					$(this).click(function(){
						let textval = $(this).parent().children("textarea").val();
						let id = this.parentElement.parentElement.parentElement.querySelector(".id").innerHTML.trim();
						$.ajax({
							type : "POST",
							url : "php/updatePatientNote.php",
							data : {
								text : textval,
								thisDay : thisDay,
								id : id
							},
							beforeSend : () =>{
								$(this).attr("disabled","disabled");
								$(this).html("Updating");
							},
							success : response =>{
								if(response == "updated")
								{
									$(this).css({backgroundColor:"blue"});
									$(this).removeAttr("disabled");
									$(this).html("Update");
								}
								else
								{
									$(this).css({backgroundColor:"red"});
									$(this).html("Failed");
									setTimeout(()=>{
										$(this).css({backgroundColor:"blue"});
										$(this).removeAttr("disabled");
										$(this).html("Updating");

									},3000);
								}
								
							}
						});
					});
				});
				$(".checkBtn").each(function(){
					$(this).click(function(){
						
						let id = this.parentElement.parentElement.parentElement.querySelector(".id").innerHTML.trim();
						let notes = this.parentElement.parentElement.parentElement.querySelector("textarea").value.trim();

						if($(this).is(":checked")){
							date = new Date();
							time = date.getHours() + ":" + date.getMinutes();
							
							$.ajax({
								type : "POST",
								url : "php/patientChecked.php",
								data : {
									thisDay : thisDay,
									id : id,
									notes : notes,
									current_time : time
								},
								beforeSend : () =>{

								},
								success : response =>{
									if(response == "updated")
									{
										
										let pre_val = this.parentElement.parentElement.parentElement.querySelector(".postTime").innerHTML.trim();
										let pre_val_parts = pre_val.split(":");
										let time_parts = time.split(":");
										color = "";
										if(pre_val_parts[0]<time_parts[0])
										{
											color = "red";
										}
										else if(pre_val_parts[0]==time_parts[0])
										{
											if(pre_val_parts[1]<time_parts[1])
											{
												color = "red";
												console.log("2");
											}
											else
											{
												color="green";
												console.log("3");
											}
										}
										else
										{
											color = "green";
											console.log("4");
										}
										this.parentElement.parentElement.parentElement.querySelector(".displayTime").innerHTML = time;
										this.parentElement.parentElement.parentElement.querySelector(".displayTime").style.color = color;
									}
								}
							});
						}
						else if($(this).is(":not(:checked)")){
							
						$.ajax({
							type : "POST",
							url : "php/patientUnChecked.php",
							data : {
								thisDay : thisDay,
								id : id
							},
							beforeSend : () =>{

							},
							success : response =>{
								this.parentElement.parentElement.parentElement.querySelector(".displayTime").innerHTML = "";
							}
						});
						}
					})
				});
			}
			else
			{
				$(".listMessage").html("<span class='text-primary'>Opps!</span> No recoud found.");
			}
			
		}
		
	});
}
	


$(document).ready(function(){
	$.ajax({
		type : "POST",
		url : "php/select_appointment_details.php",
		success : function(response){
			console.log(response);
			var json_response = JSON.parse(response);
			var i;
			for(i=0;i<json_response.length;i++)
				{
					var val = Object.values(json_response[i]);
					var str = JSON.stringify(val);
					var partial_table = str.replace('["',"");
					var table_name = partial_table.replace('"]',"");
					var arr = str.split("_");
					var date = arr[2]+"/"+arr[3]+"/"+arr[4].replace('"]',"");
					var sl_no = i+1;
					var tr = `<tr>
								<th class="text-center bg-dark text-light">`+sl_no+`</th>
								<th class="text-center bg-dark text-light">`+date+`</th>
								<th class="text-center bg-dark text-light"><button class="btn btn-primary book_details" onclick="details('`+table_name+`')">Click Here To View Details</button></th>
							</tr>`
					var tbody = document.getElementsByClassName("tbody");
					tbody[0].innerHTML += tr;
				}
				$('#myTable').DataTable();
				$('#myTable tbody').on('click', 'tr', function () {
					var data = table.row(this).data();
				} );
		}
	});
})
//$(document).ready(function(){
//	$(".book_details").each(function(){
//		$(this).click(function(){
//			alert();
//		});
//	});
//});


function details(table_name){
	$(document).ready(function(){
		$.ajax({
			type : "POST",
			url : "php/book_details.php",
			data : {
				table : table_name
			},
			success : function(response){
				var json_response = JSON.parse(response);
				$(".table-hover").parent().fadeOut(500,function(){
					$(".table-details").fadeIn(500,function(){
						
						var i;
						for(i=0;i<json_response.length;i++)
							{
								let date = json_response[i][2].replace("_","/").replace("_","/");
								let dooked_date = json_response[i][6].replace("-","/").replace("-","/");
								var tr = `<tr>
											  <th class="text-center bg-dark text-light">`+json_response[i][0]+`</th>
											  <th class="text-center bg-dark text-light">`+json_response[i][1]+`</th>
											  <th class="text-center bg-dark text-light">`+date+`</th>
											  <th class="text-center bg-dark text-light">`+json_response[i][3]+`</th>
											  <th class="text-center bg-dark text-light">`+json_response[i][4]+`</th>
											  <th class="text-center bg-dark text-light">`+json_response[i][5]+`</th>
											  <th class="text-center bg-dark text-light">`+dooked_date+`</th>
										  </tr>`;
								var tbody = document.getElementsByClassName("tbody_details");
								tbody[0].innerHTML += tr;
								
							}
							// $("#detailsTable").DataTable();
							
					});
					
				})
				
			}
		});
	});
}


$(document).ready(function(){
	$("#new_password").on("keyup",function(){
		var password = $(this);
		var pass_value = document.getElementById("new_password").value;
		if(pass_value == "")
			{
				$("#repeat_password").attr("disabled","disabled");
				$(this).css("border","1px solid red");
				$("#repeat_password").val("");
			}
		else
			{
				if(pass_value.match(/[A-Z]/g) && pass_value.match(/[a-z]/g) && pass_value.match(/[0-9]/g) && pass_value.match(/[!||@||#||$||%||&||*]/g) && pass_value.length > 7)
					{
						$(this).css("border","1px solid #ccc");
						$("#repeat_password").removeAttr("disabled");
						$(".change_btn").attr("disabled","disabled");
						$("#repeat_password").on("keyup",function(){
							if($(this).val() == $("#new_password").val())
								{
									if($("#old_password").val() != "")
										{
											$(".change_btn").removeAttr("disabled");
											$(this).css("border","1px solid #ccc");
											if($("#old_password").css("border","1px solid #ccc"));
										}
									else
										{
											$("#old_password").css("border","1px solid red");
											$("#old_password").on("keyup",function(){
												if($(this).val() != "")
													{
														if($("#repeat_password").val() == $("#new_password").val())
															{
																$(".change_btn").removeAttr("disabled");
																$("#repeat_password").css("border","1px solid #ccc");
															}
														else
															{
																$(".change_btn").attr("disabled","disabled");
																$("#repeat_password").css("border","1px solid red");
															}
													}
												else
													{
														$(".change_btn").attr("disabled","disabled");
													}					
											});
										}
								}
							else
								{
									$(this).css("border","1px solid red");
									$(".change_btn").attr("disabled","disabled");
								}
						});
					}
				else
					{
						$(this).css("border","1px solid red");
						$("#repeat_password").attr("disabled","disabled");
						$("#repeat_password").val("");
						$(".change_btn").attr("disabled","disabled");
					}
			}
	});
});


let changeTime = () =>{
	$(document).ready(function(){
		
		$(".changeTimeBtn").click(function(e){
			
			e.preventDefault();
			let time = $("#starting_time_of_the_day").val();
			let date = $("#listDate").val();
			let duration = $("#duration_of_the_day").val();
			//let final_date = date.replace("/","_").replace("/","_");
			let parts = date.split("/");
			
			let day = "";
			let month = "";
			if(parts[0].charAt(0) == "0")
			{
				day = parts[0].replace("0","");
			}
			else
			{
				day = parts[0];
			}
			if(parts[1].charAt(0) == "0")
			{
				month = parts[1].replace("0","");
			}
			else
			{
				month = parts[1];
			}
			let final_date = day+"_"+month+"_"+parts[2];
			$.ajax({
				type : "POST",
				url : "php/changeTimeOfChecking.php",
				data : {
					time : time,
					date : final_date,
					duration : duration
				},
				beforeSend : () =>{
					$(".changeTimeBtn").attr("disabled","disabled");
					$(".changeTimeBtn").html("Please wait ...");
				},
				success : response =>{
					$(".changeTimeBtn").removeAttr("disabled");
					$(".changeTimeBtn").html("Confirm");
					if(response.trim() != "error")
					{
						let json_response = JSON.parse(response);
						let postTime_span = document.querySelectorAll(".postTime");
						for(let i=0;i<json_response.length;i++)
						{
							postTime_span[i].innerHTML = json_response[i];
						}
					}
					else
					{
						alert("error");
					}
				}
			});

		});
	});
}
changeTime();



// JavaScript Document
$(document).ready(function(){
	$(".management_btn").click(function(e){
		e.preventDefault();
		var clinic_name = btoa($("#clinic_name").val());
		var clinic_address = btoa($("#clinic_address").val());
		var days = "";
		$("#days li").each(function(){
			if($(this).hasClass("active"))
				{
					days += $(this).html()+",";
				}
		});
		var seat_number = btoa($("#seat_number").val());
		let starting_time = btoa($("#starting_time").val());
		let duration = btoa($("#duration").val());
		var amount = btoa($("#amount").val());
		$.ajax({
			type : "POST",
			url : "php/account_management.php",
			data : {
				clinic_name : clinic_name,
				clinic_address : clinic_address,
				days : btoa(days),
				seat_number : seat_number,
				starting_time : starting_time,
				duration: duration,
				amount : amount
			},
			beforeSend : function(){
				$(".management_btn").html("Please Wait ...");
				$(".management_btn").attr("disabled","disabled");

			},
			success : function(response){
				$(".management_btn").html("Submit");
				$(".management_btn").removeAttr("disabled");
				if(response.trim() == "failed")
					{
						var notice = document.createElement("DIV");
						notice.className = "alert alert-warning";
						notice.innerHTML = "<b>Failed to Upload</b>";
						$(".success_message").append(notice);
						setTimeout(function(){
							$(".success_message").html("");
						},3000)
					}
				else
					{
						var notice = document.createElement("DIV");
						notice.className = "alert alert-primary";
						notice.innerHTML = "<b>Success</b>";
						$(".success_message").append(notice);
						var json_response = JSON.parse(response);
						console.log(json_response);
						$("#clinic_name").val(json_response[0].clinic_name);
						$("#clinic_address").val(json_response[0].clinic_address);
						let visit_on = json_response[0].visit_on.split(",")
						for(let j=0;j<visit_on.length;j++)
						{
							$("#days li").each(function(){
								let li = $(this);
								if($(this).html() == visit_on[j])
								{
									li.addClass("active");
								}
							});
						}
						var days = $("#days_list").html();
						let time = json_response[0].start_time.split(":");
						let hr = time[0];
						let min = time[1];
						let final_time = hr+":"+min;
						$("#starting_time").val(final_time);
						let duration_time = json_response[0].duration.split(":");
						let duration_hr = duration_time[0];
						let duration_min = duration_time[1];
						let duration_final_time = duration_hr+":"+duration_min;
						$("#duration").val(duration_final_time);
						// alert(json_response[0].duration);
						$("#seat_number").val(json_response[0].total_seat);
						$("#amount").val(json_response[0].charge_per_patient);
						setTimeout(function(){
							$(".success_message").html("");
						},3000)
					}
			}
		});
		
	});
});











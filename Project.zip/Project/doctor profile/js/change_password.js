// JavaScript Document
$(document).ready(function(){
	$(".change_btn").on("click",function(){
		var old_password = $("#old_password").val();
		var new_password = $("#new_password").val();
		var repeat_password = $("#repeat_password").val();
		$.ajax({
			type : "POST",
			url : "php/change_password.php",
			data : {
				old_password : btoa(old_password),
				new_password : btoa(new_password),
				repeat_password : btoa(repeat_password)
			},
			beforeSend : function(){
				$(".change_btn").attr("disabled","disabled");
				$(".change_btn").html("Please wait ...");
			},
			success : function(response){
				$(".change_btn").html("Change Password");
				$(".change_btn").removeAttr("disabled");
				$(".password_con form").trigger("reset");
				$(".changed_notice").html("");
				if(response.trim() == "Successfully Changed Password")
					{
						var notice = document.createElement("DIV");
						notice.className = "alert alert-primary";
						notice.innerHTML = "<b>"+response+"</b>";
						$(".changed_notice").append(notice);
						setTimeout(function(){
							$(".changed_notice").html("");
						},3000)
					}
				else
					{
						var notice = document.createElement("DIV");
						notice.className = "alert alert-warning";
						notice.innerHTML = "<b>"+response+"</b>";
						$(".changed_notice").append(notice);
						setTimeout(function(){
							$(".changed_notice").html("");
						},3000)
					}
			}
		});
	});
});
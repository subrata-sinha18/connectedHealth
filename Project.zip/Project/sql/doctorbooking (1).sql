-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2020 at 05:28 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `doctorbooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE IF NOT EXISTS `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `activation_code` varchar(10) DEFAULT NULL,
  `status` varchar(11) DEFAULT 'pending',
  `contact_number` int(20) DEFAULT NULL,
  `locality` varchar(100) DEFAULT NULL,
  `are_you` varchar(100) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `experience` int(10) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `date_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `clinic_name` varchar(50) DEFAULT NULL,
  `clinic_address` varchar(100) DEFAULT NULL,
  `visit_on` varchar(50) DEFAULT NULL,
  `total_seat` int(11) DEFAULT NULL,
  `charge_per_patient` int(11) DEFAULT NULL,
  `image_name` varchar(50) DEFAULT NULL,
  `image_path` varchar(50) DEFAULT NULL,
  `image_size` float DEFAULT NULL,
  `Approved_status` varchar(50) DEFAULT 'Not Approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `email`, `activation_code`, `status`, `contact_number`, `locality`, `are_you`, `specialization`, `experience`, `password`, `date_time`, `clinic_name`, `clinic_address`, `visit_on`, `total_seat`, `charge_per_patient`, `image_name`, `image_path`, `image_size`, `Approved_status`) VALUES
(32, 'Subrata Sinha', '1@1', '723335', 'active', 2147483647, 'Indian', 'Doctor', 'Cosmetic Surgeon -- Skin, Plastic Surgery', 12, 'f236a29d9fcdabb2f9b608d22dc2feeb', '2020-04-09 13:38:51', 'assa', 'Delhi', 'Su,Mo,Th,Sa,', 100, 500, 'pencil.jpg', '../gallery/doctor_32/pencil.jpg', 0.08, 'Not Approved'),
(33, 'Vikash Kumar', '2@2', '874158', 'active', 2147483647, 'Bihar', 'Doctor', 'General Surgeon -- Surgery', 18, 'c81e728d9d4c2f636f067f89cc14862c', '2020-04-09 13:41:08', 'CERT', 'Meerut', 'Mo,We,Th,Fr,', 10, 800, 'Coronavirus.jpg', '../gallery/doctor_33/Coronavirus.jpg', 2.03, 'Not Approved'),
(34, 'Roshan Ranjan', 'roshanranjan611@gmail.com', '754659', 'active', 2147483647, 'Delhi', 'Doctor', 'General Physican -- Medicine', 12, 'f236a29d9fcdabb2f9b608d22dc2feeb', '2020-04-15 23:04:13', 'Dewan', 'Meerut', '', 50, 500, 'Coronavirus.jpg', '../gallery/doctor_34/Coronavirus.jpg', 2.03, 'Not Approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_32_12_4_2020`
--

CREATE TABLE IF NOT EXISTS `doctor_32_12_4_2020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `doctor_32_12_4_2020`
--

INSERT INTO `doctor_32_12_4_2020` (`id`, `name`, `date`, `age`, `gender`, `phone`, `book_date`, `payment_status`) VALUES
(1, 'SUbrata', '12_4_2020', 25, 'Male', 2147483647, '2020-04-12 17:06:48', 'pending'),
(2, 'sdsd', '12_4_2020', 54, 'Male', 45454545, '2020-04-12 17:35:17', 'pending'),
(3, 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:23:44', 'pending'),
(4, 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:24:09', 'pending'),
(5, 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:25:59', 'pending'),
(6, '', '12_4_2020', 0, 'Male', 0, '2020-04-12 18:33:23', 'pending'),
(7, '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:29:51', 'pending'),
(8, '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:30:22', 'pending'),
(9, '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:33:00', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_33_13_4_2020`
--

CREATE TABLE IF NOT EXISTS `doctor_33_13_4_2020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `doctor_33_13_4_2020`
--

INSERT INTO `doctor_33_13_4_2020` (`id`, `name`, `date`, `age`, `gender`, `phone`, `book_date`, `payment_status`) VALUES
(1, 'Subrata', '13_4_2020', 45, 'Male', 2147483647, '2020-04-12 19:46:05', 'pending'),
(2, '', '13_4_2020', 0, 'Male', 0, '2020-04-12 19:49:04', 'pending'),
(3, 'Vikash', '13_4_2020', 20, 'Male', 2147483647, '2020-04-12 19:55:48', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_34_17_4_2020`
--

CREATE TABLE IF NOT EXISTS `doctor_34_17_4_2020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `doctor_34_17_4_2020`
--

INSERT INTO `doctor_34_17_4_2020` (`id`, `name`, `date`, `age`, `gender`, `phone`, `book_date`, `payment_status`) VALUES
(1, 'Subrata', '17_4_2020', 25, 'Male', 2147483647, '2020-04-15 23:12:28', 'pending'),
(2, 'sdsdsd', '17_4_2020', 34, 'Female', 2147483647, '2020-04-15 23:27:23', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_34_19_4_2020`
--

CREATE TABLE IF NOT EXISTS `doctor_34_19_4_2020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `doctor_34_19_4_2020`
--

INSERT INTO `doctor_34_19_4_2020` (`id`, `name`, `date`, `age`, `gender`, `phone`, `book_date`, `payment_status`) VALUES
(1, 'sdsdsd', '19_4_2020', 34, 'Female', 2147483647, '2020-04-15 23:28:15', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctor__`
--

CREATE TABLE IF NOT EXISTS `doctor__` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `doctor__12_4_2020`
--

CREATE TABLE IF NOT EXISTS `doctor__12_4_2020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `activation_code` varchar(10) DEFAULT NULL,
  `status` varchar(11) DEFAULT 'pending',
  `contact_number` int(20) DEFAULT NULL,
  `locality` varchar(100) DEFAULT NULL,
  `are_you` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image_name` varchar(100) DEFAULT NULL,
  `image_path` varchar(100) DEFAULT NULL,
  `image_size` int(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `activation_code`, `status`, `contact_number`, `locality`, `are_you`, `password`, `date_time`, `image_name`, `image_path`, `image_size`) VALUES
(16, 'Subrata', '1@1', '339169', 'active', 2147483647, 'Hailakandi', 'User/Patient', '317bdca9bd96e996096affa24c76e3c6', '2020-04-09 13:43:26', NULL, NULL, NULL),
(17, 'Vikash', '2@2', '275355', 'active', 555555555, 'Delhi', 'User/Patient', 'c81e728d9d4c2f636f067f89cc14862c', '2020-04-09 13:44:46', NULL, NULL, NULL),
(18, 'Subrata Sinha', 'subratasinha18sudip@gmail.com', '196611', 'active', 2147483647, 'Hailakandi', 'User/Patient', 'f236a29d9fcdabb2f9b608d22dc2feeb', '2020-04-12 16:37:03', NULL, NULL, NULL),
(19, 'Roshan Ranjan', 'roshanranjan611@gmail.com', '326868', 'active', 2147483647, '', 'User/Patient', '7a78885793ca066562f482304ef03349', '2020-04-15 23:07:33', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_18`
--

CREATE TABLE IF NOT EXISTS `user_18` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `patient_name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `doctor_name` varchar(50) DEFAULT NULL,
  `doctor_number` int(20) DEFAULT NULL,
  `clinic_name` varchar(50) DEFAULT NULL,
  `clinic_address` varchar(100) DEFAULT NULL,
  `doctor_charge` int(20) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `user_18`
--

INSERT INTO `user_18` (`id`, `email`, `patient_name`, `date`, `age`, `gender`, `phone`, `book_date`, `doctor_name`, `doctor_number`, `clinic_name`, `clinic_address`, `doctor_charge`, `payment_status`) VALUES
(1, 'subratasinha18sudip@gmail.com', 'SUbrata', '12_4_2020', 25, 'Male', 2147483647, '2020-04-12 17:06:49', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(2, 'subratasinha18sudip@gmail.com', 'sdsd', '12_4_2020', 54, 'Male', 45454545, '2020-04-12 17:35:17', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(3, 'subratasinha18sudip@gmail.com', 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:23:44', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(4, 'subratasinha18sudip@gmail.com', 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:24:09', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(5, 'subratasinha18sudip@gmail.com', 'gfgfg', '12_4_2020', 56, 'Male', 5656, '2020-04-12 18:25:59', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(6, 'subratasinha18sudip@gmail.com', '', '12_4_2020', 0, 'Male', 0, '2020-04-12 18:33:23', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(7, 'subratasinha18sudip@gmail.com', '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:29:52', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(8, 'subratasinha18sudip@gmail.com', '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:30:22', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(9, 'subratasinha18sudip@gmail.com', '', '12_4_2020', 0, 'Male', 0, '2020-04-12 19:33:01', 'Subrata Sinha', 2147483647, 'assa', 'Delhi', 500, 'pending'),
(10, 'subratasinha18sudip@gmail.com', 'Subrata', '13_4_2020', 45, 'Male', 2147483647, '2020-04-12 19:46:06', 'Vikash Kumar', 2147483647, 'CERT', 'Meerut', 800, 'pending'),
(11, 'subratasinha18sudip@gmail.com', '', '13_4_2020', 0, 'Male', 0, '2020-04-12 19:49:04', 'Vikash Kumar', 2147483647, 'CERT', 'Meerut', 800, 'pending'),
(12, 'subratasinha18sudip@gmail.com', 'Vikash', '13_4_2020', 20, 'Male', 2147483647, '2020-04-12 19:55:48', 'Vikash Kumar', 2147483647, 'CERT', 'Meerut', 800, 'pending'),
(13, 'subratasinha18sudip@gmail.com', 'sdsdsd', '17_4_2020', 34, 'Female', 2147483647, '2020-04-15 23:27:23', 'Roshan Ranjan', 2147483647, 'CERT COLLEGE', 'Meerut', 500, 'pending'),
(14, 'subratasinha18sudip@gmail.com', 'sdsdsd', '19_4_2020', 34, 'Female', 2147483647, '2020-04-15 23:28:15', 'Roshan Ranjan', 2147483647, 'CERT COLLEGE', 'Meerut', 500, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user_19`
--

CREATE TABLE IF NOT EXISTS `user_19` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `patient_name` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `book_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `doctor_name` varchar(50) DEFAULT NULL,
  `doctor_number` int(20) DEFAULT NULL,
  `clinic_name` varchar(50) DEFAULT NULL,
  `clinic_address` varchar(100) DEFAULT NULL,
  `doctor_charge` int(20) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_19`
--

INSERT INTO `user_19` (`id`, `email`, `patient_name`, `date`, `age`, `gender`, `phone`, `book_date`, `doctor_name`, `doctor_number`, `clinic_name`, `clinic_address`, `doctor_charge`, `payment_status`) VALUES
(1, 'roshanranjan611@gmail.com', 'Subrata', '17_4_2020', 25, 'Male', 2147483647, '2020-04-15 23:12:29', 'Roshan Ranjan', 2147483647, 'CERT COLLEGE', 'Meerut', 500, 'pending');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

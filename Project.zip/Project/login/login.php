<!doctype html>
<html>
<head>
<meta charset="utf-8">	
<title>Signin</title>
<link rel="icon" href="images/logo.png" type="image/icon type">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/stylesheet.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link href="https://fonts.googleapis.com/css?family=Righteous&display=swap|PT+Sans&display=swap" rel="stylesheet">
	<script src="js/jquery.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/script.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/ajax_login.js"></script>
    <script src="js/forget_password_ajax.js"></script>
    <style>
        <?php require_once("../assest/css/header.php") ?>
        <?php require_once("../assest/css/footer.php") ?>
    </style>
</head>
<body>
    <div>
        <?php require_once("../assest/html/header_one.php") ?>
        <div class="container-fluid main-form-con">
            <div class="back_position">
                <h1 class="text-primary">Login Here</h1>
                <hr style="width:30%;text-align: center;">
            <div class="form-con">
                <form class="login_form">
                    <div class="form-group">
                        <label for="login_as" class="text-dark">Login As</label>
                        <select name="login_as" id="login_as" class="form-control">
                            <option class="dropdown-item">User/Patient</option>
                            <option class="dropdown-item">Doctor</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="email" class="text-dark">Registered Email Address</label>
                        <input type="email" name="email" id="email" class="form-control" />
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password"  class="form-control"/>
                    
                    </div>
                    <div class="d-flex mb-3">
                        <div class="custom-contron custom-switch w-75 mb-3">
                            <input type="checkbox" name="accept" class="custom-control-input" id="accept" />
                            <label for="accept" class="custom-control-label float-left">Keep Me Sign In</label>   
                        </div>
                        <div class="w-25">
                            <a href="javascript:void(0)" id="forget_password_link">Forgot Password?</a>
                        </div>
                    </div>
                    
                    
                    <button class="btn btn-success text-light login_submit_btn" type="submit">Sign In</button>
                    <!-- <p class="p-0 m-0" style="clear:all">You Don't Have an Account <a hreh="signup/signup.html">Sign Up</a></p> -->
                    
                </form>
                <div class="login_notice p-2">
                    
                </div>
                <div class="px-2 mt-3 d-none login_activator">
                    <span>Check Your Email to Get Actovation Code</span>
                    <input type="number" name="code" id="login_code" class="form-control my-3" placeholder="Activation Code" />
                    <button class="btn btn-dark activate_btn">Activate Now</button>
                
                </div>
                <div class="forget_password_box" style="display:none">
                    <form class="form_1">
                        <div class="form-group">
                            <label for="login_as" class="text-dark">Login As</label>
                            <select name="login_as" id="forgot_login_as" class="form-control">
                                <option class="dropdown-item">User/Patient</option>
                                <option class="dropdown-item">Doctor</option>
                            </select>
                        </div>
                        <div class="form-group check_email_con">
                        <label for="email" class="text-dark">Registered Email Address</label>
                            <input type="email" name="email" id="forget_password_email" class="form-control" />
                            
                        </div>
                            
                        
                        <button class="btn btn-warning check_email mt-3">Next Step</button>
                            
                    </form>
                    

                    
                </div>
                <div class="email_check_notice p-2">
                    
                </div>
            </div>

            </div>
            
        </div>
        <!--Start Footer-->
        <?php require_once("../assest/html/footer.php") ?>
    </div>
</body>
</html>
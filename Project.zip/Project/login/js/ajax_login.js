// JavaScript Document
$(document).ready(function(){
	$(".login_submit_btn").click(function(e){
		e.preventDefault();
		var login_as = btoa($("#login_as").val());
		var login_as_val = $("#login_as").val();
		var email = btoa($("#email").val());
		var password = btoa($("#password").val());
		$.ajax({
			type : "POST",
			url : "../php/login.php",
			data : {
				login_as : login_as,
				email : email,
				password : password
			},
			beforeSend : function(){
				$(".login_submit_btn").html("Procesing ...");
				$(".login_submit_btn").attr("disabled","disabled");
			},
			success : function(response){
				if(response.trim() == "login success")
					{
						if(login_as_val == "Doctor")
						{
							window.location = "../doctor profile/doctor.php";
						}
						else
						{
							window.location = "../user profile/user.php";
						}
					}
				else if(response.trim() == "login pending")
					{
						$(".login_form").fadeOut(500,function(){
							$(".login_activator").removeClass("d-none");
							$(".activate_btn").click(function(){
								$.ajax({
									type : "POST",
									url : "../php/activator.php",
									data : {
										code : btoa($("#login_code").val()),
										email : btoa($("#email").val()),
										login_as : login_as
									},
									beforeSend : function(){
										$(".login_submit_btn").html("Please wait ...");
										$(".login_submit_btn").attr("disabled","disbaled");
									},
									success : function(response){
										if(response.trim() == "Users varified")
											{
												if(login_as_val == "Doctor")
													{
														window.location = "../doctor profile/doctor.php";
													}
												else
													{
														window.location = "../user profile/user.php";
													}
											}
										else
											{
												$(".activate_btn").html("Activate Now");
												$(".activate_btn").removeAttr("disabled");
												$("#login_code").val("");
												var notice = document.createElement("DIV");
												notice.className = "alert alert-warning";
												notice.innerHTML = "<b>"+response+"</b>";
												$(".login_notice").append(notice);
												setTimeout(function(){
													$(".signup_notice").html("");
												},3000)
											}
									}
								});
							})
						});
					}
				else if(response.trim() == "worng password")
					{
						var message = document.createElement("DIV");
						message.className = "alert alert-warning";
						message.innerHTML = "<b>Wrong Password</b>";
						$(".login_notice").append(message);
						$(".login_form").trigger("reset");
						$(".login_submit_btn").html("Login");
						$(".login_submit_btn").removeAttr("disabled");
						setTimeout(function(){
							$(".login_notice").html("");
						},2000);
					}
				else
					{
						message = document.createElement("DIV");
						message.className = "alert alert-warning";
						message.innerHTML = "<b>User Not Found</b>";
						$(".login_notice").append(message);
						$(".login_form").trigger("reset");
						$(".login_submit_btn").html("Login");
						$(".login_submit_btn").removeAttr("disabled");
						setTimeout(function(){
							$(".login_notice").html("");
						},2000);
					}
			},
		});
	});
});

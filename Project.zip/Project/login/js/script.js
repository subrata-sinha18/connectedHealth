// JavaScript Document

// dynamic navbar toggler
$(document).ready(function(){
	$("#nav-icon").click(function(){
		$("#mobile-menu").collapse('toggle');
		$("#mobile-menu").addClass("animated zoomIn");
	});
});



$(document).ready(function(){
	$("#login_as").on("change",function(){
		if($(this).val() == "Doctor")
		{
			$(".appear").html('<div class="form-group"><label for="login_as" class="text-dark">Select Specialization</label><select name="login_as" id="login_as" class="form-control"><option class="dropdown-item">Select Specialization</option><option class="dropdown-item">Anesthesiologist -- Anesthesis for surgery</option><option class="dropdown-item">Cardiac Surgeon -- Specializes in surgical procedures of the heart, lungs, esophagus, and other organs</option><option class="dropdown-item">Cardiologist -- Heart disease</option><option class="dropdown-item">Cardiologist and Diabetologist -- Heart Diseases and Diabetics</option><option class="dropdown-item">Consultant Physician -- Medicine</option><option class="dropdown-item">Consultant Physician & Diabetologist -- </option><option class="dropdown-item">Cosmetic Surgeon -- Skin, Plastic Surgery </option><option class="dropdown-item">Dentist -- Teeth doctor</option><option class="dropdown-item">Dermatologist -- Skin doctor</option><option class="dropdown-item">Diabetologist -- Diabetes</option><option class="dropdown-item">Endocrinologist -- Thyroid disease</option><option class="dropdown-item">ENT -- Ear, Nose, Throat</option><option class="dropdown-item">For Test -- Testing Purpose</option><option class="dropdown-item">Gastroenterologist -- Diseases of the digestive system</option><option class="dropdown-item">Gastroenterologist & Hepatologist -- Acid Reflux, Indigestion and Vomiting. Peptic Ulcer Disease, Liver , Gallbladder etc</option><option class="dropdown-item">General & Laparoscopic surgery -- </option><option class="dropdown-item">General Physican -- Medicine</option><option class="dropdown-item">General Surgeon -- Surgery</option><option class="dropdown-item">Gynaecologist -- Pregnancy, Childbirth, Woman Health etc</option><option class="dropdown-item">Hepatologist -- Liver Expert</option><option class="dropdown-item">Homeopathy -- Homeopathy doctor</option><option class="dropdown-item">Nephrologist -- Kidney disease</option><option class="dropdown-item">Neurologist -- Brain, Nervous system</option><option class="dropdown-item">Neuropsychiatrist -- Brains, Nerves, Mental disorders etc</option><option class="dropdown-item">Neurosurgeon -- Brain, Nerves</option><option class="dropdown-item">Oncologist -- Cancer doctor</option><option class="dropdown-item">SpecializatiOphthalmologist -- Eye doctoron</option><option class="dropdown-item">Optometrist -- For Defects in Vision and Eye Disorders</option><option class="dropdown-item">Orthodontist -- Teeth</option><option class="dropdown-item">Orthopaedic -- Bone, fractures, back-pain</option><option class="dropdown-item">Pathologist -- Blood test, urine test etc</option><option class="dropdown-item">Pediatrician -- Child doctor</option><option class="dropdown-item">Physiotherapist --  Physical therapy</option><option class="dropdown-item">Psychiatrist -- Mental disorders</option><option class="dropdown-item">Radiologist -- X-ray, MRI etc</option><option class="dropdown-item">Rheumatologist -- Rheumatology</option><option class="dropdown-item">Rheumatology -- Arthritis, Joint Point & Nerve</option><option class="dropdown-item">Urologist -- Urinary tract</option><option class="dropdown-item">Veteninary -- Animal doctor</option><optopn>Employee</optopn></select></div><div class="form-group"><label for="experience">Experience in Years</label><input type="number" name="number" id="experience"  class="form-control"/></div>')
		}
		else
		{
			$(".appear").html("");
		}
	})
});

$(document).ready(function(){
	$(".login").each(function(){
		$(this).on("click",function(){
			window.location = "login.php";
		})
	});
});
$(document).ready(function(){
	$(".signup").each(function(){
		$(this).on("click",function(){
			window.location = "../signup/signup.php";
		})
	});
});

$(document).ready(function(){
	$("#forget_password_link").click(function(){
		$(".login_form").fadeOut(500,function(){
			$(".forget_password_box").fadeIn(500);
			
		})
	});
});


$(document).ready(function(){
	$('input[type="checkbox"]').click(function(){
		if($(this).prop("checked") == true){
			let login = btoa($("#login_as").val());
			let username = btoa($("#email").val());
			let pass = btoa($("#password").val());
			document.cookie = 'login_as='+login;
			document.cookie = 'email='+username;
			document.cookie = 'password='+pass;



		}
		else if($(this).prop("checked") == false){
			console.log("Checkbox is unchecked.");
		}
	});
});

$(document).ready(function(){
	let cookies = document.cookie;

	let co_split = cookies.split(";");
	for(let i=0;i<co_split.length;i++)
	{
		let parts = co_split[i].split("=");
		let idName = parts[0].trim();
		let ele = document.getElementById(idName);
		ele.value = atob(parts[1]);
	}
	// let login_as_parts = co_split[0].split("=");
	// let login_as_val = atob(login_as_parts[1]);
	// $("#login_as").val(login_as_val);
	// let email_parts = co_split[1].split("=");
	// let email_val = atob(email_parts[1]);
	// $("#email").val(email_val);
	// let pass_parts = co_split[2].split("=");
	// let pass_val = atob(pass_parts[1]);
	// $("#password").val(pass_val);

});
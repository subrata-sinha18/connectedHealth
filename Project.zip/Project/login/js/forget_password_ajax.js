// JavaScript Document
$(document).ready(function(){
	$(".check_email").click(function(event){
		event.preventDefault();
		var email = $("#forget_password_email").val();
		var login_as = $("#forgot_login_as").val();
		$.ajax({
			type : "POST",
			url : "../php/check_email.php",
			data : {
				email : btoa(email),
				login_as : btoa(login_as)
			},
			beforeSend : function(){
				$(".check_email").attr("disabled","disabled");
				$(".check_email").html("Please wait ...");
			},
			success : function(response){
				console.log(response);
				$("email_check_notice").html("");
				$(".check_email").removeAttr("disabled");
				$(".check_email").html("Next step");
				if(response.trim() == "Updated")
					{

						var form_2 = `<form class="form_2">
										
										<div class="form-group password">
											<label for="update_password_activation" class="text-dark">Enter Activation Code</label>
											<input type="number" name="email" id="update_password_activation" class="form-control" />
										</div>
										<button class="btn btn-warning update_password_activation_btn mt-3" disabled="disabled">Procced</button>
									</form>`;
						$(".forget_password_box").html(form_2);
						$("#update_password_activation").on("keyup",function(){
							if($(this).val().length == 6)
								{
									var activation_code = $(this).val();
									$(".update_password_activation_btn").removeAttr("disabled");
									$(".update_password_activation_btn").click(function(e){
										e.preventDefault();
										$.ajax({
											type : "POST",
											url : "../php/check_activation_code.php",
											data : {
												activation_code : btoa(activation_code),
												email : btoa(email),
												login_as : btoa(login_as)
											},
											beforeSend : function(){
												$(".update_password_activation_btn").attr("disabled","disabled");
												$(".update_password_activation_btn").html("Please wait ...");
											},
											success : function(res){
												if(res.trim() == "Matched")
													{
														var form_3 = `<form class="form_3">
																		
																			<div class="form-group password">
																				<label for="update_password" class="text-dark">Entre New Password</label>
																				<input type="password" name="email" id="update_password" class="form-control" />

																			</div>
																			<div class="form-group password">
																				<label for="confirm_update_password" class="text-dark">Confirm Password</label>
																				<input type="password" name="email" id="confirm_update_password" disabled="disabled" class="form-control" />

																			</div>
																		<button class="btn btn-warning update_password_btn mt-3">Change Password</button>
																	

																</form>`;
														$(".forget_password_box").html(form_3);
														$("#update_password").on("keyup",function(){
															var new_val = document.getElementById("update_password").value;
															if(new_val  != "")
																{
																	if(new_val.match(/[A-Z]/g) && new_val.match(/[a-z]/g) && new_val.match(/[0-9]/g) && new_val.match(/[!||@||#||$||%||&||*]/g) && new_val.length > 7)
																		{
																			$(this).css("border","1px solid #ccc");
																			$("#confirm_update_password").removeAttr("disabled");
																			$("#confirm_update_password").on("keyup",function(){

																				if(new_val == $(this).val())
																					{
																						let final_password = $(this).val();
																						$(this).css("border","1px solid #ccc");
																						$(".update_password_btn").removeAttr("disabled");
																						$(".update_password_btn").click(function(p){
																							p.preventDefault();
																							$.ajax({
																								type : "POST",
																								url : "../php/update_password.php",
																								data : {
																									email :btoa(email),
																									password : btoa(final_password),
																									login_as : btoa(login_as)
																								},
																								beforeSend : function(){
																									$(".update_password_btn").attr("disabled","disabled");
																									$(".update_password_btn").html("Please wait...");
																								},
																								success : function(resp){
																									$(".update_password_btn").removeAttr("disabled");
																									$(".update_password_btn").html("Change Password");
																									$(".email_check_notice").html("");
																									if(resp.trim() == "Updated")
																										{
																											var div = document.createElement("DIV");
																											div.className = "alert alert-primary";
																											div.innerHTML = "Password Changed Successfully";
																											$(".email_check_notice").append(div);
																											setTimeout(function(){
																												$(".email_check_notice").html("");
																												window.location = location.href;
																											},3000);
																										}
																									else
																										{
																											var div = document.createElement("DIV");
																											div.className = "alert alert-warning";
																											div.innerHTML = "Something Went Wrong, Please Try Again !";
																											$(".email_check_notice").append(div);
																											setTimeout(function(){
																												$(".email_check_notice").html("");
																												window.location = location.href;
																											},3000);
																										}
																								}
																								
																							});
																							
																						});
																					}
																				else
																					{
																						$(this).css("border","1px solid red");
																						$(".update_password_btn").attr("disabled","disabled");

																					}
																			});
																		}
																	else
																		{
																			$("#confirm_update_password").attr("disabled","disabled");
																			$(this).css("border","1px solid red");
																		}
																}
															else
																{
																	$("#confirm_update_password").attr("disabled","disabled");
																	$(this).css("border","1px solid red");
																}
														});
														
														
													}
												else
													{
														var div = document.createElement("DIV");
														div.className = "alert alert-warning";
														div.innerHTML = res;

														$(".email_check_notice").append(div);
														setTimeout(function(){
															$(".email_check_notice").html("");
														},3000);
												
													}
												
											}
										});
									});
								}
							else
								{
									$(".update_password_activation_btn").attr("disabled","disabled");
								}

						});
					}
				else
					{
						
						var div = document.createElement("DIV");
						div.className = "alert alert-warning";
						div.innerHTML = response;
						
						$(".email_check_notice").append(div);
						setTimeout(function(){
							$(".email_check_notice").html("");
						},2000);
					}
			}
		});
	});
});
<?php
$db = new mysqli("localhost","root","","doctorbooking");
if($db->connect_error)
{
	die("Database not connected");
}


 
?>
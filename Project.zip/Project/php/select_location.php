<?php
require_once("database.php");
$value = $_POST['value'];
$select_region = "SELECT locality FROM doctors WHERE locality LIKE '%$value%'";
if($region_response = $db->query($select_region))
{
    if($region_response->num_rows != 0)
    {
        while($data = $region_response->fetch_assoc())
        {
            $region[] = $data['locality'];
        //	$arry_data = array_unique($region);
            
            
        }
        $uni = array_unique($region);
        if(count($uni) > 0)
        {
            
            echo json_encode($uni);
        }
        else
        {
            echo "not";
        }
    }
    else
    {
        echo "not";
    }
    
    
}
else
{
    echo "not";
}


?>
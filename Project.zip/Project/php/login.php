<?php
require("database.php");
$login_as = base64_decode($_POST["login_as"]);
$email = base64_decode($_POST['email']);
$password = md5(base64_decode($_POST['password']));
if($login_as == "Doctor")
{
	$check_email = "SELECT email FROM doctors WHERE email = '$email'";
	$email_response = $db->query($check_email);
	if($email_response->num_rows != 0)
	{
		$check_email = "SELECT email,password FROM doctors WHERE email = '$email' AND password = '$password'";
		$response_password = $db->query($check_email);
		if($response_password->num_rows != 0)
		{
			$check_status = "SELECT status FROM doctors WHERE email = '$email' AND password = '$password' AND status = 'active'";
			$response_status = $db->query($check_status);
			if($response_status->num_rows != 0)
			{
				session_start();
				$_SESSION['email'] = $email;
				echo "login success";
			}
			else
			{
				$get_code = "SELECT activation_code FROM doctors WHERE email = '$email' AND password = '$password'";
				$response_get_code = $db->query($get_code);
				$data = $response_get_code->fetch_assoc();
				$final_code = $data['activation_code'];
				$check_code_mail = mail($email,"Doctor Patient Activation Code","Thank you for choosingour product. Your activation code is : ".$final_code);
				if($check_code_mail)
				{
					echo "login pending";
				}
			}
		}
		else
		{
			echo "worng password";
		}
	}
	else
	{
		echo "user not found";
	}
}
else
	{
		$check_email = "SELECT email FROM users WHERE email = '$email'";
		$email_response = $db->query($check_email);
		if($email_response->num_rows != 0)
		{
			$check_email = "SELECT email,password FROM users WHERE email = '$email' AND password = '$password'";
			$response_password = $db->query($check_email);
			if($response_password->num_rows != 0)
			{
				$check_status = "SELECT status FROM users WHERE email = '$email' AND password = '$password' AND status = 'active'";
				$response_status = $db->query($check_status);
				if($response_status->num_rows != 0)
				{
					session_start();
					$_SESSION['email'] = $email;
					echo "login success";
				}
				else
				{
					$get_code = "SELECT activation_code FROM users WHERE email = '$email' AND password = '$password'";
					$response_get_code = $db->query($get_code);
					$data = $response_get_code->fetch_assoc();
					$final_code = $data['activation_code'];
					$check_code_mail = mail($email,"Doctor Patient Activation Code","Thank you for choosingour product. Your activation code is : ".$final_code);
					if($check_code_mail)
					{
						echo "login pending";
					}
				}
			}
			else
			{
				echo "worng password";
			}
		}
		else
		{
			echo "user not found";
		}
	}



?>
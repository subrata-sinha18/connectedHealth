<?php
require("database.php");
session_start();

if($_SESSION['payment'] == "active")
{
	echo "not found";
	header("Location:../user profile/user.php");
	exit;
}
else
{
	$user_email = $_SESSION['email'];
	$date = $_GET['date'];
	$id = $_GET['doctor_id'];
	$patient_name = $_GET['patient_name'];
	$age = $_GET['age'];
	$gender = $_GET['gender'];
	$phone = $_GET['phone'];
	$total_seat = $_GET['total_seat'];
	$table_name = "doctor_".$id."_".$date;
	$get_user = "SELECT id FROM users WHERE email = '$user_email'";
	$response = $db->query($get_user);
	$id_data = $response->fetch_assoc();
	$user_id = $id_data['id'];
	$user_table = "user_".$user_id;
	$doctor_details = "SELECT name,contact_number,clinic_name,clinic_address,charge_per_patient,duration FROM doctors WHERE id = '$id'";
	$doctor_details_response = $db->query($doctor_details);
	$doctor_details_data = $doctor_details_response->fetch_assoc();
	$doctor_name = $doctor_details_data['name'];
	$doctor_number = $doctor_details_data['contact_number'];
	$doctor_clinic_name = $doctor_details_data['clinic_name'];
	$doctor_clinic_address = $doctor_details_data['clinic_address'];
	$doctor_charge = $doctor_details_data['charge_per_patient'];
	$doctor_duration = $doctor_details_data['duration'];
	$count_total_booked = "SELECT COUNT(id) AS total FROM $user_table";
	$total_booked = 0;
	if($total_response = $db->query($count_total_booked))
	{
		$total_data = $total_response->fetch_assoc();
		$total_booked = $total_data['total']+1;
	}
	
	$table_query = "CREATE TABLE IF NOT EXISTS $table_name(
		id INT(11) NOT NULL  AUTO_INCREMENT,
		name VARCHAR(20),
		date VARCHAR(20),
		age INT(10),
		gender VARCHAR(20),
		phone VARCHAR(20),
		book_date DATETIME DEFAULT CURRENT_TIMESTAMP,
		payment_status VARCHAR(50) DEFAULT 'pending',
		notes VARCHAR(250),
		check_status VARCHAR(50) DEFAULT 'not checked',
		checked_time TIME(5),
		checked_at TIME(5),
		total_count INT(10),
		user INT(10),
		PRIMARY KEY(id)
		)";
	if($db->query($table_query))
	{
		$count_query = "SELECT COUNT(id) AS total FROM $table_name";
		$count_response = $db->query($count_query);
		$cound_data = $count_response->fetch_assoc();
		if($cound_data['total'] < $total_seat)
		{
			$insert_data = "INSERT INTO $table_name (name,date,age,gender,phone,total_count,user)VALUES('$patient_name','$date','$age','$gender','$phone','$total_booked','$user_id')";
			if($db->query($insert_data))
			{
				$user_table_query = "CREATE TABLE IF NOT EXISTS $user_table(
					id INT(11) NOT NULL AUTO_INCREMENT,
					email VARCHAR(50),
					patient_name VARCHAR(20),
					date VARCHAR(20),
					age INT(10),
					gender VARCHAR(20),
					phone VARCHAR(20),
					book_date DATETIME DEFAULT CURRENT_TIMESTAMP,
					doctor_name VARCHAR(50),
					doctor_number VARCHAR(20),
					clinic_name VARCHAR(50),
					clinic_address VARCHAR(100),
					doctor_charge INT(20),
					check_status VARCHAR(50) DEFAULT 'not checked',
					notes VARCHAR(250),
					total_booked INT(10),
					checked_time TIME(5),
					checked_at TIME(5),
					payment_status VARCHAR(50) DEFAULT 'pending',
					PRIMARY KEY(id)
					)";
				if($db->query($user_table_query))
				{


					$select_time = "SELECT start_time,duration FROM doctors WHERE id = '$id'";
					if($response_time = $db->query($select_time))
					{
						$data_time = $response_time->fetch_assoc();
						$start_time = $data_time['start_time'];
						$start_time_parts = explode(":",$start_time);
						$actual_starting_time = $start_time_parts[0].":".$start_time_parts[1];
						$duration = $data_time['duration'];
						$count_patient = "SELECT COUNT(id) AS total_patient FROM $table_name";
						if($total_patient_response = $db->query($count_patient))
						{
							$patient_data = $total_patient_response->fetch_assoc();
							$total_patient = $patient_data['total_patient'];
							$duration_parts = explode(":",$duration);
							$duration_in_minute = (60*$duration_parts[0])+$duration_parts[1];
							$patient_duration = $duration_in_minute*($total_patient-1);
							
							function addMinutesToTime( $dateTime, $plusMinutes ) {

								$dateTime = DateTime::createFromFormat( 'Y-m-d H:i', $dateTime );
								$dateTime->add( new DateInterval( 'PT' . ( (integer) $plusMinutes ) . 'M' ) );
								$newTime = $dateTime->format( 'Y-m-d H:i' );
							
								return $newTime;
							}
							$bookdate_parts = explode("_",$date);
							$bookDate = $bookdate_parts[2]."-".$bookdate_parts[1]."-".$bookdate_parts[0];
							$request_date = $bookDate." ".$actual_starting_time;
							$request_time = strval($request_date);
							$patient_duration_time = strval($patient_duration);
							$adjustedTime = addMinutesToTime( $request_time,$patient_duration_time );

							$insert_patient_details = "INSERT INTO $user_table (email,patient_name,date,age,gender,phone,doctor_name,doctor_number,clinic_name,clinic_address,doctor_charge,total_booked,checked_time)VALUES('$user_email','$patient_name','$date','$age','$gender','$phone','$doctor_name','$doctor_number','$doctor_clinic_name','$doctor_clinic_address','$doctor_charge','$total_booked','$adjustedTime')";
							if($db->query($insert_patient_details))
							{
								$message = "BOOKED SUCCESSFULLY";
								

							}
							else
							{
								$message = "DATA NOT INSERTED TO USER TABLE";
							}



						}
						else
						{
							echo "not count";
						}
					}
					else
					{
						echo "not able to retrive time";
					}






					


					
				}
				else
				{
					$message = "USER TABLE NOT CREATED SUCCESSFULLY";
				}

			}
			else
			{
				$message = "DATA NOT INSERTED TO DOCTOR TABLE";
			}
		}
		else
		{
			$message = "SEAT FULL";
		}
	}
	else
	{
		$message = "DOCTOR TABLE NOT CREATED SUCCESSFULLY";
	}
	$_SESSION['payment'] = "active";
}


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
		*{
			padding:0;
			margim:0;
		}
		body
		{
			background-color:#000;
			padding-top:100px;
		}
	</style>
</head>

<body>
	<h1 style="text-align:center;color:white;font-family:sans-serif;font-size:40px;"><?php echo $message ?></h1>
	<script>
		setTimeout(function(){
			window.location = "../user profile/user.php";
		},10000);
	</script>
	
</body>
</html>




<?php
require("database.php");
$email = base64_decode($_POST['email']);
$login_as = base64_decode($_POST["login_as"]);
if($login_as == "Doctor")
{
	$check_email = "SELECT email FROM doctors WHERE email = '$email'";
	if($email_response = $db->query($check_email))
	{
		if($email_response->num_rows != 0)
		{
			$pattern = "123456789";
			$length = strlen($pattern)-1;
			$i;
			$code = [];
			for($i=0;$i<6;$i++)
			{
				$indexing_number = rand(0,$length);
				$code[] = $pattern[$indexing_number];
			}
			$activation_code = implode($code);
			$update_query = "UPDATE doctors SET activation_code = '$activation_code' WHERE email = '$email'";
			if($db->query($update_query))
			{
				$check_mail = mail($email,"Your Activation Code","Thank you for choosing this site. Your activation Code is : ".$activation_code);
				if($check_mail)
				{
					echo "Updated";
				}
				else
				{
					echo "sending failed";
				}
			}
			else
			{
				echo "Error";
			}

		}
		else
		{
			echo "Account Not Found 2";
		}
	}
	else
	{
		echo "Account Not Found 1";
	}
}
else
{
	$check_email = "SELECT email FROM users WHERE email = '$email'";
	if($email_response = $db->query($check_email))
	{
		if($email_response->num_rows != 0)
		{
			$pattern = "123456789";
			$length = strlen($pattern)-1;
			$i;
			$code = [];
			for($i=0;$i<6;$i++)
			{
				$indexing_number = rand(0,$length);
				$code[] = $pattern[$indexing_number];
			}
			$activation_code = implode($code);
			$update_query = "UPDATE users SET activation_code = '$activation_code' WHERE email = '$email'";
			if($db->query($update_query))
			{
				// echo "Updated";
				$check_mail = mail($email,"Your Activation Code","Thank you for choosing this site. Your activation Code is : ".$activation_code);
				if($check_mail)
				{
					echo "Updated";
				}
				else
				{
					echo "sending failed";
				}
			}
			else
			{
				echo "Error";
			}

		}
		else
		{
			echo "Account Not Found 2";
		}
	}
	else
	{
		echo "Account Not Found 1";
	}
}




?>
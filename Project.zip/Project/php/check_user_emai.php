<?php
require("database.php");
$email = base64_decode($_POST["email"]);
$login_as = base64_decode($_POST["login_as"]);
if($login_as == "Doctor")
{
	$change = "SELECT email from doctors WHERE email = '$email'";
	$response = $db->query($change);
	if($response->num_rows != 0)
	{
		echo "user found";
	}
	else
	{
		echo "user not found";
	}
}
else
{
	$change = "SELECT email from users WHERE email = '$email'";
	$response = $db->query($change);
	if($response->num_rows != 0)
	{
		echo "user found";
	}
	else
	{
		echo "user not found";
	}
}


?>
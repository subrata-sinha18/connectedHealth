<?php
require_once("database.php");
$region = $_POST['locality'];
$select_region = "SELECT specialization FROM doctors WHERE locality = '$region'";
$special_response = $db->query($select_region);

while($data = $special_response->fetch_assoc())
{
	$special[] = $data['specialization'];
//	$arry_data = array_unique($region);


}
echo json_encode($special);
// $uniq = array_unique($special);
// echo json_encode($uniq);

?>
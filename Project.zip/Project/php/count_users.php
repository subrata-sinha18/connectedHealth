<?php
require("database.php");
$count_query = "SELECT count(id) AS result FROM users";
if($response = $db->query($count_query))
{
    $data = $response->fetch_assoc();

        echo $data['result'];
}




?>
<?php
require("database.php");
$count_query = "SELECT count(id) AS result FROM doctors";
if($response = $db->query($count_query))
{
    $data = $response->fetch_assoc();

    echo $data['result'];
}




?>
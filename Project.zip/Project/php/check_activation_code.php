<?php
require("database.php");
$activation_code = base64_decode($_POST["activation_code"]);
$email = base64_decode($_POST["email"]);
$login_as = base64_decode($_POST['login_as']);
if($login_as == "Doctor")
{
	$select_activation = "SELECT activation_code FROM doctors WHERE email = '$email'";
	$activation_response = $db->query($select_activation);
	$old_data = $activation_response->fetch_assoc();
	$old_activation = $old_data['activation_code'];
	if($activation_code == $old_activation)
	{
		echo "Matched";
	}
	else
	{
		echo "Wrong Activation Code";
	}
}
else
{
	$select_activation = "SELECT activation_code FROM users WHERE email = '$email'";
	$activation_response = $db->query($select_activation);
	$old_data = $activation_response->fetch_assoc();
	$old_activation = $old_data['activation_code'];
	if($activation_code == $old_activation)
	{
		echo "Matched";
	}
	else
	{
		echo "Wrong Activation Code";
	}
}

?>
<?php
require("database.php");
$email = base64_decode($_POST["email"]);
$password = md5(base64_decode($_POST['password']));
$login_as = base64_decode($_POST['login_as']);
if($login_as == "Doctor")
{
	$update_query = "UPDATE doctors SET password = '$password' WHERE email = '$email'";
	if($response = $db->query($update_query))
	{
		echo "Updated";
	}
	else
	{
		echo "Not updated";
	}
}
else
{
	$update_query = "UPDATE users SET password = '$password' WHERE email = '$email'";
	if($response = $db->query($update_query))
	{
		echo "Updated";
	}
	else
	{
		echo "Not updated";
	}

}


?>
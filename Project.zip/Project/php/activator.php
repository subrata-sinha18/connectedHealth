<?php
require("database.php");
$code = base64_decode($_POST['code']);
$email = base64_decode($_POST['email']);
$login_as = base64_decode($_POST['login_as']);

if($login_as == "Doctor")
{
	$check_code = "SELECT activation_code FROM doctors WHERE email = '$email' AND activation_code = '$code'";
	$response = $db->query($check_code);

	if($response->num_rows != 0)
	{
		$update_ststus = "UPDATE doctors SET status = 'active' WHERE email = '$email' AND activation_code = '$code'";
		if($db->query($update_ststus))
		{
			$get_id = "SELECT id FROM doctors WHERE email = '$email'";
			$get_id_response = $db->query($get_id);
			$id_data = $get_id_response->fetch_assoc();
			$table_name = "doctor_".$id_data['id'];
			mkdir("../doctor profile/gallery/".$table_name);
				session_start();
				$_SESSION['email'] = $email;
				echo "Users varified";
			
//			$create_table = "CREATE TABLE $table_name(
//				id INT(11) NOT NULL  AUTO_INCREMENT,
//				clinic_name VARCHAR(50),
//				clinic_address VARCHAR(100),
//				visit_on VARCHAR(100),
//				total_seats INT(11),
//				charge_per_patient INT(11),
//				image_name VARCHAR(50),
//				image_path VARCHAR(50),
//				image_size FLOAT(10),
//				image_date DATETIME DEFAULT CURRENT_TIMESTAMP,
//				PRIMARY KEY(id)
//				)";
//			if($db->query($create_table))
//			{
//				mkdir("../doctor profile/gallery/".$table_name);
//				session_start();
//				$_SESSION['email'] = $email;
//				echo "Users varified";
//				
//			}
//			else
//			{
//				echo "table not created";
//			}
		}
		else
		{
			echo "activation failed";
		}
	}
	else
	{
		echo "Wrong Activation Code";
	}
}
else
{
	$check_code = "SELECT activation_code FROM users WHERE email = '$email' AND activation_code = '$code'";
	$response = $db->query($check_code);
	if($response->num_rows != 0)
	{
		$update_ststus = "UPDATE users SET status = 'active' WHERE email = '$email' AND activation_code = '$code'";
		if($db->query($update_ststus))
		{
			session_start();
			$_SESSION['email'] = $email;
			echo "Users varified";
			
		}
		else
		{
			echo "activation failed";
		}
	}
	else
	{
		echo "Wrong Activation Code";
	}
}

?>
<?php
require("database.php");
$select_clinic= "SELECT locality FROM doctors";
if($response = $db->query($select_clinic))
{
    if($response->num_rows != 0)
    {
        while($data = $response->fetch_assoc())
        {
            $region[] = $data['locality'];
        }
        $uni = array_unique($region);
        $total_clinic =  count($uni);
        echo $total_clinic;
    }
    else
    {
        echo "not";
    }
    
    
}




?>
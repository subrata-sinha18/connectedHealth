<?php
require("database.php");
$region = base64_decode($_POST['region']);
$specialization = base64_decode($_POST['specialization']);
$search_query = "SELECT email FROM doctors WHERE locality='$region' AND specialization = '$specialization'";
$search_response = $db->query($search_query);

while($search_data = $search_response->fetch_assoc())
{
	$doctor_email[] = $search_data['email'];
}
$email_length = sizeof($doctor_email);
$i;
for($i=0;$i<$email_length;$i++)
{
	$email_name = $doctor_email[$i];
	$doctor_query = "SELECT name,email,locality,specialization FROM doctors WHERE email = '$email_name'";
	$doctor_response = $db->query($doctor_query);
	$doctor_data = $doctor_response->fetch_assoc();
	$name = $doctor_data['name'];
	$email = $doctor_data['email'];
	$locality = $doctor_data['locality'];
	$speaial = $doctor_data['specialization'];
	$doctor[] = [$name,$email,$locality,$speaial];
}
echo json_encode($doctor);

?>